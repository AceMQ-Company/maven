/*
 * Copyright 2026 AceMQ.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.acemq.amqp.transport.rabbitmq;

import java.io.IOException;
import java.time.Duration;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

import org.acemq.amqp.transport.Acknowledger;
import org.acemq.amqp.transport.ConfirmResult;
import org.acemq.amqp.transport.ConnectionBlockedException;
import org.acemq.amqp.transport.ConnectionConfig;
import org.acemq.amqp.transport.DeliveryListener;
import org.acemq.amqp.transport.InboundDelivery;
import org.acemq.amqp.transport.OutboundMessage;
import org.acemq.amqp.transport.QueueCheck;
import org.acemq.amqp.transport.QueueType;
import org.acemq.amqp.transport.Subscription;
import org.acemq.amqp.transport.TransportConnection;
import org.acemq.amqp.transport.TransportException;
import org.jspecify.annotations.Nullable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.rabbitmq.client.AMQP;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.DefaultConsumer;
import com.rabbitmq.client.Envelope;
import com.rabbitmq.client.MessageProperties;
import com.rabbitmq.client.ShutdownSignalException;

/**
 * A RabbitMQ connection presented as a {@link TransportConnection}.
 *
 * <p>Channels are an implementation detail and never escape this class. Publishing uses one
 * dedicated confirm-mode channel guarded by a lock, because an AMQP 0-9-1 channel is not
 * thread safe and sharing one unguarded is a classic source of protocol errors under load.
 * Each subscription gets its own channel, so a slow consumer cannot stall a publisher.
 */
final class RabbitMqConnection implements TransportConnection {

    private static final Logger log = LoggerFactory.getLogger(RabbitMqConnection.class);

    /** AMQP 0-9-1 reply code 406: what the broker says when a declare disagrees with reality. */
    private static final int PRECONDITION_FAILED = 406;

    private final Connection connection;
    private final ConnectionConfig config;
    private final Channel publishChannel;
    private final Object publishLock = new Object();

    /**
     * What a return on {@link #publishChannel} said about the publish in flight on it.
     *
     * <p>A synchronous publish holds the channel's lock until its confirm arrives, and the broker
     * sends a return before the confirm for the same message, so any return seen in that window
     * is this publish's. Matching by message id instead missed every message without one: a
     * parked or replayed foreign message came back unroutable and was reported as routed.
     */
    private final java.util.concurrent.atomic.AtomicReference<@Nullable String> publishReturned = new java.util.concurrent.atomic.AtomicReference<>();

    /**
     * The channel confirmed publishes go out on: {@link #publishChannel} when the connection has
     * confirms, and a channel of its own when it was made without them, which then carries only
     * {@link OutboundMessage#alwaysConfirmed()} publishes — what the library sends on a caller's
     * behalf. Recovered with the connection like any other channel, in confirm mode again.
     */
    private final Channel confirmedChannel;
    private final Object confirmedLock;
    private final java.util.concurrent.atomic.AtomicReference<@Nullable String> confirmedReturned;
    private final List<Channel> consumerChannels = new CopyOnWriteArrayList<>();
    private final Map<String, String> returnedMessages = new ConcurrentHashMap<>();
    private final AtomicBoolean closed = new AtomicBoolean();

    /**
     * Every open stream subscription's position, rewound just before the client recovers its
     * consumer. A queue subscription is not here: recovering it as it was is already right.
     */
    private final java.util.Set<StreamPosition> streams = ConcurrentHashMap.newKeySet();

    /**
     * The pool every handler on this connection runs on.
     *
     * <p>Owned here because the client only shuts down a dispatch pool it created itself, and
     * this one was handed to it. Left to expire on its own, its threads would outlive every
     * connection that ever used one.
     */
    private final ExecutorService dispatch;

    /**
     * The broker's reason for refusing publishes, or null when it is accepting them.
     *
     * <p>Guarded by {@link #blockedLock} for waiting, and volatile so a reader asking
     * {@link #isBlocked()} never has to take the lock.
     */
    private volatile @Nullable String blockedReason;

    private final Object blockedLock = new Object();

    /** Opened on first asynchronous publish; most connections never publish that way. */
    private volatile @Nullable Channel asyncPublishChannel;

    private final Object asyncLock = new Object();

    /**
     * Publishes waiting for a confirm, keyed by delivery sequence number.
     *
     * <p>Sorted, because a confirm can acknowledge every sequence number up to a given one and
     * answering that question on a hash map would mean scanning all of it per confirm.
     */
    private final java.util.concurrent.ConcurrentSkipListMap<Long, PendingPublish> pending = new java.util.concurrent.ConcurrentSkipListMap<>();

    private final java.util.concurrent.Semaphore outstanding;

    RabbitMqConnection(Connection connection, ConnectionConfig config, ExecutorService dispatch) {
        this.connection = connection;
        this.config = config;
        this.dispatch = dispatch;
        this.outstanding = new java.util.concurrent.Semaphore(config.maxOutstandingPublishes());
        try {
            this.publishChannel = connection.createChannel();
            if (config.publisherConfirms()) {
                this.publishChannel.confirmSelect();
                this.confirmedChannel = publishChannel;
                this.confirmedLock = publishLock;
                this.confirmedReturned = publishReturned;
            } else {
                this.confirmedChannel = connection.createChannel();
                this.confirmedChannel.confirmSelect();
                this.confirmedLock = new Object();
                this.confirmedReturned = new java.util.concurrent.atomic.AtomicReference<>();
                watchReturns(confirmedChannel, confirmedReturned);
            }
            watchReturns(publishChannel, publishReturned);
        } catch (IOException e) {
            throw new TransportException("could not open the publishing channel", e);
        }

        if (connection instanceof com.rabbitmq.client.Recoverable) {
            ((com.rabbitmq.client.Recoverable) connection)
                    .addRecoveryListener(new com.rabbitmq.client.RecoveryListener() {
                        @Override
                        public void handleRecovery(com.rabbitmq.client.Recoverable recoverable) {
                        }

                        @Override
                        public void handleRecoveryStarted(com.rabbitmq.client.Recoverable recoverable) {
                        }

                        @Override
                        public void handleTopologyRecoveryStarted(com.rabbitmq.client.Recoverable recoverable) {
                            // Runs on the recovery thread just before the consumers are recovered, with
                            // the very argument maps the client recorded for them.
                            streams.forEach(StreamPosition::rewind);
                        }
                    });
        }

        // Without this listener a memory or disk alarm is invisible: the broker stops reading
        // from the socket, basicPublish keeps returning, and the confirm never comes. The
        // publisher waits forever with nothing logged anywhere.
        connection.addBlockedListener(
                reason -> {
                    synchronized (blockedLock) {
                        blockedReason = reason == null ? "the broker did not say" : reason;
                        blockedLock.notifyAll();
                    }
                    log.error("the broker has blocked this connection: {}. Publishing is refused{} until it"
                            + " unblocks. This is a broker capacity problem, not a client one.",
                            blockedReason, config.blockedTimeout().isZero()
                                    ? ""
                                    : " after waiting up to " + config.blockedTimeout());
                },
                () -> {
                    synchronized (blockedLock) {
                        blockedReason = null;
                        blockedLock.notifyAll();
                    }
                    log.info("the broker has unblocked this connection; publishing resumes");
                });
    }

    /**
     * A returned message means the broker accepted it but nothing was bound to receive it. The
     * confirm still arrives, so the return has to be recorded here and read when it lands.
     */
    private static void watchReturns(Channel channel,
            java.util.concurrent.atomic.AtomicReference<@Nullable String> slot) {
        channel.addReturnListener((replyCode, replyText, exchange, routingKey, properties, body) -> {
            slot.set(replyCode + " " + replyText);
            log.warn("message returned as unroutable: exchange={} routingKey={} reason={} {}",
                    exchange, routingKey, replyCode, replyText);
        });
    }

    @Override
    public boolean isBlocked() {
        return blockedReason != null;
    }

    @Override
    public java.util.Optional<String> blockedReason() {
        return java.util.Optional.ofNullable(blockedReason);
    }

    /**
     * Refuses a publish while the broker is blocking them, after waiting up to
     * {@code blockedTimeout} for it to resume.
     *
     * <p>The timeout is zero by default, so a publish into a known alarm is refused at once and
     * nothing is written -- what Python, .NET and Ruby do, and what the AceMQ TCK requires. A
     * caller that would rather ride out a brief alarm sets a timeout and waits instead. Waiting
     * without a bound is what this exists to prevent.
     */
    private void awaitUnblocked() {
        if (blockedReason == null) {
            return;
        }
        long deadline = System.nanoTime() + config.blockedTimeout().toNanos();
        synchronized (blockedLock) {
            while (blockedReason != null) {
                long remaining = deadline - System.nanoTime();
                if (remaining <= 0) {
                    throw new ConnectionBlockedException("the broker is refusing publishes (" + blockedReason + ")"
                            + (config.blockedTimeout().isZero()
                                    ? ""
                                    : " and did not resume within " + config.blockedTimeout())
                            + ", so nothing was sent. This is broker capacity, not this message: back off"
                            + " rather than retrying immediately.", blockedReason);
                }
                try {
                    blockedLock.wait(Math.max(1L, remaining / 1_000_000L));
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    throw new TransportException("interrupted while waiting for the broker to unblock", e);
                }
            }
        }
    }

    @Override
    public void declareExchange(String name, String type, boolean durable) {
        withChannel("declare exchange " + name, channel -> {
            channel.exchangeDeclare(name, type, durable);
            return null;
        });
    }

    @Override
    public void declareQueue(String name, QueueType type, boolean durable, Map<String, Object> arguments) {
        Map<String, Object> args = declarationArguments(type, arguments);
        // Quorum and stream queues must be durable; declaring otherwise fails at the broker
        // with a message that does not explain itself, so it is corrected here.
        boolean effectiveDurable = durable || type != QueueType.CLASSIC;

        withChannel("declare queue " + name, channel -> {
            channel.queueDeclare(name, effectiveDurable, false, false, args);
            return null;
        });
    }

    /**
     * The arguments that actually reach the broker.
     *
     * <p>Shared with {@link #checkQueue}, which has to offer the identical set: an equivalence
     * declare that left out {@code x-queue-type} would report drift against a quorum queue the
     * topology asked for and got.
     */
    private static Map<String, Object> declarationArguments(QueueType type, @Nullable Map<String, Object> arguments) {
        Map<String, Object> args = arguments == null ? new HashMap<>() : new HashMap<>(arguments);
        if (type == QueueType.QUORUM) {
            args.put("x-queue-type", "quorum");
        } else if (type == QueueType.STREAM) {
            args.put("x-queue-type", "stream");
        }
        return args;
    }

    @Override
    public void bindQueue(String queue, String exchange, String routingKey) {
        withChannel("bind " + queue + " to " + exchange, channel -> {
            channel.queueBind(queue, exchange, routingKey);
            return null;
        });
    }

    @Override
    public void deleteQueue(String name) {
        withChannel("delete queue " + name, channel -> {
            channel.queueDelete(name);
            return null;
        });
    }

    @Override
    public ConfirmResult send(OutboundMessage message) {
        // Before the lock, not inside it: a blocked broker would otherwise hold the publishing
        // channel's monitor for the whole timeout and stall every other publisher with it.
        awaitUnblocked();

        AMQP.BasicProperties properties = properties(message);
        long startedAt = System.nanoTime();

        // What the library publishes on a caller's behalf is confirmed whatever the connection
        // was made with: each settles something on the answer, and without a confirm the
        // answer can only ever be "routed". The caller's own publishes keep their mode.
        boolean confirm = config.publisherConfirms() || message.alwaysConfirmed();
        Channel channel = confirm ? confirmedChannel : publishChannel;
        java.util.concurrent.atomic.AtomicReference<@Nullable String> returnSlot = confirm
                ? confirmedReturned
                : publishReturned;

        synchronized (confirm ? confirmedLock : publishLock) {
            try {
                returnSlot.set(null);
                channel.basicPublish(
                        message.exchange(), message.routingKey(), message.mandatory(), properties, message.body());

                if (!confirm) {
                    return ConfirmResult.confirmed(elapsedSince(startedAt));
                }

                boolean acked = awaitConfirm(channel, message);
                Duration latency = elapsedSince(startedAt);
                if (!acked) {
                    return ConfirmResult.failed(latency, "the broker rejected the message");
                }

                // waitForConfirms returning true only means the broker took the message. If
                // it was also returned as unroutable, that return has already arrived.
                String returned = returnSlot.getAndSet(null);
                return returned == null
                        ? ConfirmResult.confirmed(latency)
                        : ConfirmResult.unroutable(latency, returned);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                throw new TransportException("interrupted while waiting for a publisher confirm", e);
            } catch (IOException | ShutdownSignalException e) {
                throw new TransportException("publish failed: " + message, e);
            } catch (java.util.concurrent.TimeoutException e) {
                throw new TransportException(
                        "no publisher confirm within " + config.confirmTimeout() + " for " + message, e);
            }
        }
    }

    /**
     * Waits for the confirm, treating "the broker is in alarm" differently from "the confirm is
     * late".
     *
     * <p>This is where a resource alarm is actually discovered. RabbitMQ does not tell an idle
     * connection that an alarm has started; it tells a connection when that connection publishes.
     * The first message into an alarm is therefore already on the wire before anything is known,
     * and its confirm simply never arrives. Left to the ordinary confirm timeout, the caller is
     * told "no publisher confirm within 10s" — true, useless, and pointing at the wrong system.
     *
     * <p>While the connection is blocked the total wait is bounded by the longer of
     * {@code confirmTimeout} and {@code blockedTimeout}. With the default zero blocked timeout that
     * is the confirm timeout: the message was written before the alarm was known, so it gets the
     * confirm wait any message gets and then fails as possibly published, rather than hanging
     * until the alarm clears.
     */
    private boolean awaitConfirm(Channel channel, OutboundMessage message)
            throws InterruptedException, java.util.concurrent.TimeoutException {
        Duration bound = config.blockedTimeout().compareTo(config.confirmTimeout()) > 0
                ? config.blockedTimeout()
                : config.confirmTimeout();
        long blockedDeadline = System.nanoTime() + bound.toNanos();
        while (true) {
            long confirmWaitMillis = config.confirmTimeout().toMillis();
            if (isBlocked()) {
                long remainingMillis = (blockedDeadline - System.nanoTime()) / 1_000_000L;
                if (remainingMillis <= 0) {
                    throw new ConnectionBlockedException("the broker blocked publishing ("
                            + blockedReason().orElse("no reason given") + ") and did not confirm " + message
                            + " within " + bound + ". It may or may not have arrived; this is a"
                            + " broker capacity problem, so back off rather than retrying immediately.",
                            blockedReason().orElse("unknown"), true);
                }
                confirmWaitMillis = Math.min(confirmWaitMillis, remainingMillis);
            }
            try {
                return channel.waitForConfirms(Math.max(1L, confirmWaitMillis));
            } catch (java.util.concurrent.TimeoutException e) {
                // A plain late confirm is not this method's problem: report it as it always was.
                if (!isBlocked()) {
                    throw e;
                }
            }
        }
    }

    @Override
    public Subscription subscribe(String queue, int prefetch, DeliveryListener listener) {
        return subscribe(queue, prefetch, Collections.emptyMap(), listener);
    }

    @Override
    public Subscription subscribe(
            String queue, int prefetch, Map<String, Object> consumerArguments, DeliveryListener listener) {
        if (prefetch < 1) {
            throw new IllegalArgumentException(
                    "prefetch must be at least 1, was " + prefetch + ". Unbounded prefetch is the fastest way to run"
                            + " a consumer out of memory, so it cannot be requested by accident."
                            + " A stream additionally requires it: the broker refuses a stream consumer with no"
                            + " prefetch, because a stream has no other way to stop.");
        }
        // Always a map of our own: the client keeps this instance to recover the consumer with,
        // which is what lets a stream's position be moved before it does.
        Map<String, Object> arguments = consumerArguments == null
                ? new HashMap<>()
                : new HashMap<>(consumerArguments);
        StreamPosition position = arguments.containsKey(StreamPosition.ARGUMENT)
                ? new StreamPosition(arguments)
                : null;
        try {
            Channel channel = connection.createChannel();
            channel.basicQos(prefetch);
            consumerChannels.add(channel);

            String consumerTag = channel.basicConsume(queue, false, arguments, new DefaultConsumer(channel) {
                @Override
                public void handleDelivery(
                        String tag, Envelope envelope, AMQP.BasicProperties properties, byte[] body) {
                    // Recorded before the handler sees it and settled before the broker is
                    // told, so a recovery at any point finds it either pending or done.
                    Runnable settle = null;
                    Long offset = position == null ? null : StreamPosition.offsetOf(properties.getHeaders());
                    if (position != null && offset != null) {
                        StreamPosition tracked = position;
                        long at = offset;
                        int token = tracked.delivered(at);
                        settle = () -> tracked.settle(at, token);
                    }
                    InboundDelivery delivery = new InboundDelivery(
                            queue,
                            envelope.getExchange(),
                            envelope.getRoutingKey(),
                            body,
                            portableHeaders(properties.getHeaders()),
                            properties.getMessageId(),
                            properties.getContentType(),
                            envelope.isRedeliver(),
                            properties.getReplyTo());
                    listener.onDelivery(delivery, new ChannelAcknowledger(channel, envelope.getDeliveryTag(), settle));
                }
            });
            if (position == null) {
                return new ChannelSubscription(queue, channel, consumerTag, consumerChannels, null);
            }
            streams.add(position);
            return new ChannelSubscription(queue, channel, consumerTag, consumerChannels,
                    () -> streams.remove(position));
        } catch (IOException e) {
            throw new TransportException("could not consume queue " + queue, e);
        }
    }

    @Override
    public boolean queueExists(String name) {
        // A passive declare asks without creating. It fails the channel when the queue is
        // absent, which is why this runs on a throwaway channel rather than the publishing
        // one: the question must not be able to break unrelated traffic.
        try (Channel channel = connection.createChannel()) {
            channel.queueDeclarePassive(name);
            return true;
        } catch (IOException e) {
            return false;
        } catch (Exception e) {
            throw new TransportException("could not check whether queue '" + name + "' exists", e);
        }
    }

    @Override
    public QueueCheck checkQueue(String name, QueueType type, boolean durable, Map<String, Object> arguments) {
        if (!queueExists(name)) {
            return QueueCheck.absent();
        }

        // The queue is there, so a declare cannot create one, and the broker itself will say
        // whether the settings match. Nothing else can answer this: AMQP has no way to read a
        // queue's arguments back, only to offer some and be told they are wrong. RabbitMQ's
        // refusal names the offending argument and both values, which is more than an
        // inspection API would have given us anyway.
        //
        // On its own channel, because a mismatch closes the channel it happens on.
        Map<String, Object> args = declarationArguments(type, arguments);
        boolean effectiveDurable = durable || type != QueueType.CLASSIC;
        try (Channel channel = connection.createChannel()) {
            channel.queueDeclare(name, effectiveDurable, false, false, args);
            return QueueCheck.matches();
        } catch (IOException e) {
            String reason = shutdownReason(e);
            if (reason == null) {
                throw new TransportException("could not check queue '" + name + "' against the topology", e);
            }
            return QueueCheck.differs(reason);
        } catch (Exception e) {
            throw new TransportException("could not check queue '" + name + "' against the topology", e);
        }
    }

    /**
     * Digs the broker's own words out of a failed declare.
     *
     * <p>A 406 PRECONDITION_FAILED names the argument and both values — "inequivalent arg
     * 'x-message-ttl' for queue 'orders.new' in vhost '/': received none but current is the
     * value '60000'". Rewriting that into something tidier would lose the two values, which are
     * the only part anybody needs.
     *
     * @return the reason, or {@code null} if this failure was not the broker refusing
     */
    private static @Nullable String shutdownReason(IOException e) {
        Throwable cause = e.getCause();
        if (!(cause instanceof ShutdownSignalException)) {
            return null;
        }
        Object reason = ((ShutdownSignalException) cause).getReason();
        if (!(reason instanceof AMQP.Channel.Close)) {
            return null;
        }
        AMQP.Channel.Close close = (AMQP.Channel.Close) reason;
        if (close.getReplyCode() != PRECONDITION_FAILED) {
            return null;
        }
        return close.getReplyText();
    }

    @Override
    public boolean isOpen() {
        return !closed.get() && connection.isOpen();
    }

    @Override
    public void close() {
        if (!closed.compareAndSet(false, true)) {
            return;
        }
        for (Channel channel : consumerChannels) {
            closeQuietly(channel);
        }
        consumerChannels.clear();
        closeQuietly(publishChannel);
        if (confirmedChannel != publishChannel) {
            closeQuietly(confirmedChannel);
        }
        try {
            connection.close();
        } catch (IOException e) {
            log.debug("ignoring error while closing the connection", e);
        }
        // After the connection, so anything the client still wanted to dispatch during shutdown
        // has somewhere to run. Not awaited: everything that had to finish was drained before
        // close() was reached, and a handler still running past that point is one the caller
        // has already decided not to wait for.
        dispatch.shutdown();
    }

    private AMQP.BasicProperties properties(OutboundMessage message) {
        AMQP.BasicProperties base = message.persistent() ? MessageProperties.PERSISTENT_BASIC : MessageProperties.BASIC;
        return base.builder()
                .headers(message.headers())
                .messageId(message.messageId())
                .contentType(message.contentType())
                // AMQP carries the time-to-live as a string of milliseconds, oddly enough, and
                // RabbitMQ rejects anything else on the channel rather than ignoring it.
                .expiration(message.expiration().map(ttl -> String.valueOf(ttl.toMillis())).orElse(null))
                .priority(message.priority().orElse(null))
                .replyTo(message.replyTo().orElse(null))
                .build();
    }

    private static Duration elapsedSince(long startedAtNanos) {
        return Duration.ofNanos(System.nanoTime() - startedAtNanos);
    }

    /**
     * Converts RabbitMQ's header types into the portable ones the SPI promises.
     *
     * <p>The client returns text headers as {@code LongString}, which is not a
     * {@code CharSequence} and does not equal the {@code String} that was published. Left
     * alone it reaches application code and makes an ordinary header comparison fail for
     * reasons that have nothing to do with the application. Nested lists and maps are
     * converted too, since a header value may contain them.
     */
    private static @Nullable Map<String, Object> portableHeaders(@Nullable Map<String, Object> headers) {
        if (headers == null) {
            return null;
        }
        Map<String, Object> portable = new HashMap<>(headers.size());
        headers.forEach((name, value) -> portable.put(name, portableValue(value)));
        return portable;
    }

    private static @Nullable Object portableValue(@Nullable Object value) {
        if (value instanceof com.rabbitmq.client.LongString) {
            return value.toString();
        }
        if (value instanceof List) {
            List<Object> converted = new java.util.ArrayList<>(((List<?>) value).size());
            for (Object element : (List<?>) value) {
                converted.add(portableValue(element));
            }
            return converted;
        }
        if (value instanceof Map) {
            Map<String, Object> converted = new HashMap<>();
            ((Map<?, ?>) value).forEach((key, nested) -> converted.put(String.valueOf(key), portableValue(nested)));
            return converted;
        }
        return value;
    }

    /**
     * Runs a one-off administrative operation on its own channel.
     *
     * <p>A failed declaration kills the channel it ran on. Using a throwaway channel keeps
     * that failure away from the publishing channel, which would otherwise take every
     * in-flight publish down with it.
     */
    @Override
    public java.util.concurrent.CompletableFuture<ConfirmResult> sendAsync(OutboundMessage message) {
        if (!config.publisherConfirms()) {
            // Nothing to correlate: without confirms there is no answer to wait for, so the
            // synchronous path is already as asynchronous as this can honestly be.
            return java.util.concurrent.CompletableFuture.completedFuture(send(message));
        }

        awaitUnblocked();

        Channel channel = asyncChannel();
        AMQP.BasicProperties properties = properties(message);
        long startedAt = System.nanoTime();

        // Bounded before the message is written, not after. This is the only backpressure an
        // asynchronous publisher has: without it a caller that publishes faster than the broker
        // confirms accumulates unconfirmed messages until the process dies, which looks like
        // throughput right up to the moment it does not.
        try {
            if (!outstanding.tryAcquire(config.confirmTimeout().toMillis(), TimeUnit.MILLISECONDS)) {
                throw new TransportException(config.maxOutstandingPublishes() + " publishes are already waiting for"
                        + " a confirm and none completed within " + config.confirmTimeout() + ". The broker is not"
                        + " keeping up; publish more slowly rather than buffering more.");
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new TransportException("interrupted while waiting for room to publish", e);
        }

        java.util.concurrent.CompletableFuture<ConfirmResult> future = new java.util.concurrent.CompletableFuture<>();
        try {
            // The sequence number and the publish have to be taken together under one lock.
            // getNextPublishSeqNo only predicts the number the *next* publish will use, so two
            // threads interleaving here would file their futures under each other's numbers and
            // every confirm after that would be attributed to the wrong message.
            synchronized (asyncLock) {
                long sequence = channel.getNextPublishSeqNo();
                pending.put(sequence, new PendingPublish(message.messageId(), startedAt, future));
                try {
                    channel.basicPublish(message.exchange(), message.routingKey(), message.mandatory(),
                            properties, message.body());
                } catch (IOException | ShutdownSignalException e) {
                    pending.remove(sequence);
                    throw e;
                }
            }
        } catch (Exception e) {
            outstanding.release();
            throw new TransportException("could not publish " + message, e);
        }
        return future;
    }

    /** Opens the asynchronous publishing channel on first use, and wires its confirm listener. */
    private Channel asyncChannel() {
        Channel existing = asyncPublishChannel;
        if (existing != null && existing.isOpen()) {
            return existing;
        }
        synchronized (asyncLock) {
            if (asyncPublishChannel != null && asyncPublishChannel.isOpen()) {
                return asyncPublishChannel;
            }
            try {
                Channel channel = connection.createChannel();
                channel.confirmSelect();
                channel.addReturnListener((replyCode, replyText, exchange, routingKey, props, body) -> {
                    // A return always precedes the confirm for the same message, so recording it
                    // here and reading it when the confirm lands is enough to tell "the broker
                    // took it" apart from "the broker took it and nothing wanted it".
                    String id = props == null ? null : props.getMessageId();
                    if (id != null) {
                        returnedMessages.put(id, replyCode + " " + replyText);
                    }
                    log.warn("message returned as unroutable: exchange={} routingKey={} reason={} {}",
                            exchange, routingKey, replyCode, replyText);
                });
                channel.addConfirmListener(
                        (sequence, multiple) -> settle(sequence, multiple, true, null),
                        (sequence, multiple) -> settle(sequence, multiple, false, null));
                channel.addShutdownListener(cause -> {
                    // Every outstanding future would otherwise wait forever for a confirm that
                    // can no longer arrive. Failing them is the only honest answer: those
                    // messages may or may not have reached the broker.
                    failAllPending(new TransportException(
                            "the publishing channel closed with " + pending.size() + " publish(es) unconfirmed;"
                                    + " those messages may or may not have arrived",
                            cause));
                });
                asyncPublishChannel = channel;
                return channel;
            } catch (IOException e) {
                throw new TransportException("could not open the asynchronous publishing channel", e);
            }
        }
    }

    /**
     * Completes the futures a confirm covers.
     *
     * <p>Confirms arrive out of order and in ranges: {@code multiple} means "every sequence number
     * up to and including this one". Completing only the exact number would leave the rest of a
     * range pending forever, and leak a permit each time.
     */
    private void settle(long sequence, boolean multiple, boolean acknowledged, @Nullable String reason) {
        Map<Long, PendingPublish> settled = new java.util.HashMap<>();
        if (multiple) {
            java.util.NavigableMap<Long, PendingPublish> upTo = pending.headMap(sequence, true);
            settled.putAll(upTo);
            upTo.clear();
        } else {
            PendingPublish one = pending.remove(sequence);
            if (one != null) {
                settled.put(sequence, one);
            }
        }

        settled.forEach((number, publish) -> {
            outstanding.release();
            Duration latency = elapsedSince(publish.startedAt);
            if (!acknowledged) {
                publish.future.complete(ConfirmResult.failed(latency,
                        reason == null ? "the broker rejected the message" : reason));
                return;
            }
            String returned = publish.messageId == null ? null : returnedMessages.remove(publish.messageId);
            publish.future.complete(returned == null
                    ? ConfirmResult.confirmed(latency)
                    : ConfirmResult.unroutable(latency, returned));
        });
    }

    private void failAllPending(TransportException failure) {
        java.util.List<PendingPublish> abandoned = new java.util.ArrayList<>(pending.values());
        pending.clear();
        for (PendingPublish publish : abandoned) {
            outstanding.release();
            publish.future.completeExceptionally(failure);
        }
    }

    /** One publish waiting for its confirm. */
    private static final class PendingPublish {

        private final @Nullable String messageId;
        private final long startedAt;
        private final java.util.concurrent.CompletableFuture<ConfirmResult> future;

        PendingPublish(@Nullable String messageId, long startedAt,
                java.util.concurrent.CompletableFuture<ConfirmResult> future) {
            this.messageId = messageId;
            this.startedAt = startedAt;
            this.future = future;
        }
    }

    @Override
    public java.util.Optional<org.acemq.amqp.transport.PulledMessage> receive(String queue, Duration timeout) {
        // Its own channel, kept open past the return. basicGet leaves the message unsettled and
        // an acknowledgement is only valid on the channel that delivered it, so the usual
        // open-use-close helper cannot be used here: closing would requeue the message the
        // caller is holding.
        Channel channel;
        try {
            channel = connection.createChannel();
        } catch (IOException e) {
            throw new TransportException("could not open a channel to read from '" + queue + "'", e);
        }

        long deadline = System.nanoTime() + timeout.toNanos();
        try {
            while (true) {
                com.rabbitmq.client.GetResponse response = channel.basicGet(queue, false);
                if (response != null) {
                    return java.util.Optional.of(pulled(queue, channel, response));
                }
                if (System.nanoTime() - deadline >= 0) {
                    closeQuietly(channel);
                    return java.util.Optional.empty();
                }
                // basicGet answers immediately, so an empty queue has to be re-asked rather than
                // waited on. Polling is acceptable here only because this is a drain, not a
                // consumer: nothing on the message path is built out of it.
                Thread.sleep(Math.min(50L, Math.max(1L, (deadline - System.nanoTime()) / 1_000_000L)));
            }
        } catch (InterruptedException e) {
            closeQuietly(channel);
            Thread.currentThread().interrupt();
            throw new TransportException("interrupted while reading from '" + queue + "'", e);
        } catch (IOException | ShutdownSignalException e) {
            closeQuietly(channel);
            throw new TransportException("could not read from '" + queue + "'", e);
        }
    }

    private org.acemq.amqp.transport.PulledMessage pulled(
            String queue, Channel channel, com.rabbitmq.client.GetResponse response) {
        AMQP.BasicProperties properties = response.getProps();
        InboundDelivery delivery = new InboundDelivery(
                queue,
                response.getEnvelope().getExchange(),
                response.getEnvelope().getRoutingKey(),
                response.getBody(),
                portableHeaders(properties.getHeaders()),
                properties.getMessageId(),
                properties.getContentType(),
                response.getEnvelope().isRedeliver(),
                properties.getReplyTo());

        long deliveryTag = response.getEnvelope().getDeliveryTag();
        AtomicBoolean settled = new AtomicBoolean();
        Acknowledger acknowledger = new Acknowledger() {

            @Override
            public void accept() {
                settle(() -> channel.basicAck(deliveryTag, false));
            }

            @Override
            public void reject(boolean requeue) {
                settle(() -> channel.basicNack(deliveryTag, false, requeue));
            }

            private void settle(SettleOperation operation) {
                // The channel closes with the settlement, because it exists only to carry it.
                // Leaking one channel per pulled message would exhaust the connection during
                // exactly the operation this was written for: draining a large queue.
                if (!settled.compareAndSet(false, true)) {
                    throw new IllegalStateException("this message has already been settled");
                }
                try {
                    operation.run();
                } catch (IOException e) {
                    throw new TransportException("could not settle a message pulled from '" + queue + "'", e);
                } finally {
                    closeQuietly(channel);
                }
            }
        };
        return new org.acemq.amqp.transport.PulledMessage(delivery, acknowledger);
    }

    @FunctionalInterface
    private interface SettleOperation {
        void run() throws IOException;
    }

    @Override
    public long messageCount(String queue) {
        Long count = withChannel("count the messages in '" + queue + "'", channel -> channel.messageCount(queue));
        return count == null ? 0L : count;
    }

    private <T> @Nullable T withChannel(String description, ChannelOperation<T> operation) {
        try (Channel channel = connection.createChannel()) {
            return operation.run(channel);
        } catch (Exception e) {
            throw new TransportException("could not " + description, e);
        }
    }

    private static void closeQuietly(Channel channel) {
        try {
            if (channel.isOpen()) {
                channel.close();
            }
        } catch (Exception e) {
            log.debug("ignoring error while closing a channel", e);
        }
    }

    @FunctionalInterface
    private interface ChannelOperation<T> {
        @Nullable
        T run(Channel channel) throws Exception;
    }

    /** Settles one delivery, refusing to settle it twice. */
    private static final class ChannelAcknowledger implements Acknowledger {

        private final Channel channel;
        private final long deliveryTag;
        private final AtomicBoolean settled = new AtomicBoolean();
        private final @Nullable Runnable onSettle;

        ChannelAcknowledger(Channel channel, long deliveryTag, @Nullable Runnable onSettle) {
            this.channel = channel;
            this.deliveryTag = deliveryTag;
            this.onSettle = onSettle;
        }

        @Override
        public void accept() {
            if (settled.compareAndSet(false, true)) {
                if (onSettle != null) {
                    onSettle.run();
                }
                try {
                    channel.basicAck(deliveryTag, false);
                } catch (IOException | ShutdownSignalException e) {
                    // The delivery will be redelivered when the channel closes. Failing loudly
                    // here would be worse: the message is not lost, only unsettled. That
                    // includes a channel already lost to a dropped connection, whose late
                    // acknowledgement once escaped into the handler and stopped a stream reader.
                    log.warn("could not acknowledge delivery {}", deliveryTag, e);
                }
            }
        }

        @Override
        public void reject(boolean requeue) {
            if (settled.compareAndSet(false, true)) {
                if (onSettle != null) {
                    onSettle.run();
                }
                try {
                    channel.basicNack(deliveryTag, false, requeue);
                } catch (IOException | ShutdownSignalException e) {
                    log.warn("could not reject delivery {}", deliveryTag, e);
                }
            }
        }
    }

    /** A consumer registration tied to its own channel. */
    private static final class ChannelSubscription implements Subscription {

        private final String queue;
        private final Channel channel;
        private final String consumerTag;
        private final List<Channel> registry;
        private final AtomicBoolean active = new AtomicBoolean(true);
        private final @Nullable Runnable forget;

        ChannelSubscription(String queue, Channel channel, String consumerTag, List<Channel> registry,
                @Nullable Runnable forget) {
            this.queue = queue;
            this.channel = channel;
            this.consumerTag = consumerTag;
            this.registry = registry;
            this.forget = forget;
        }

        private void forget() {
            if (forget != null) {
                forget.run();
            }
        }

        @Override
        public String queue() {
            return queue;
        }

        @Override
        public void cancel() {
            if (!active.compareAndSet(true, false)) {
                return;
            }
            forget();
            try {
                // basic.cancel stops delivery and leaves the channel open, so anything already
                // dispatched can still be acknowledged on it.
                if (channel.isOpen()) {
                    channel.basicCancel(consumerTag);
                }
            } catch (IOException e) {
                log.debug("could not cancel the consumer on {}", queue, e);
            }
        }

        @Override
        public void setPrefetch(int prefetch) {
            if (prefetch < 1) {
                throw new IllegalArgumentException("prefetch must be at least 1, was " + prefetch);
            }
            try {
                // AMQP allows basic.qos on a channel that is already consuming; it applies to
                // deliveries after this point. Nothing needs recreating.
                channel.basicQos(prefetch);
            } catch (IOException e) {
                throw new TransportException("could not change the prefetch on queue " + queue + " to " + prefetch, e);
            }
        }

        @Override
        public boolean isActive() {
            return active.get() && channel.isOpen();
        }

        @Override
        public void close() {
            if (!active.compareAndSet(true, false)) {
                return;
            }
            forget();
            try {
                if (channel.isOpen()) {
                    // Cancelling before closing lets deliveries already dispatched finish
                    // settling, rather than turning a clean shutdown into redeliveries.
                    channel.basicCancel(consumerTag);
                }
            } catch (Exception e) {
                log.debug("ignoring error while cancelling consumer {}", consumerTag, e);
            }
            registry.remove(channel);
            closeQuietly(channel);
        }
    }
}
