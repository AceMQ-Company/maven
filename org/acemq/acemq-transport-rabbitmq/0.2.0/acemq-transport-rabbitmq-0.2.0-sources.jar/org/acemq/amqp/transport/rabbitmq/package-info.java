/*
 * Copyright 2026 AceMQ.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * AMQP 0-9-1 transport backed by the RabbitMQ Java client.
 *
 * <p>Only {@code RabbitMqTransport} is public. Everything else is package private on purpose:
 * a caller who can reach a channel is a caller whose code stops working when the broker
 * changes, which is exactly what this library exists to prevent.
 */

@org.jspecify.annotations.NullMarked
package org.acemq.amqp.transport.rabbitmq;
