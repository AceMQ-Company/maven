/*
 * Copyright 2026 AceMQ.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.acemq.amqp.test;

import java.time.Duration;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Semaphore;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

import org.acemq.amqp.transport.Acknowledger;
import org.acemq.amqp.transport.ConfirmResult;
import org.acemq.amqp.transport.DeliveryListener;
import org.acemq.amqp.transport.InboundDelivery;
import org.acemq.amqp.transport.OutboundMessage;
import org.acemq.amqp.transport.QueueCheck;
import org.acemq.amqp.transport.QueueType;
import org.acemq.amqp.transport.Subscription;
import org.acemq.amqp.transport.TransportConnection;
import org.acemq.amqp.transport.TransportException;

/** A connection to an {@link InMemoryBroker}. */
final class InMemoryConnection implements TransportConnection {

    private static final AtomicInteger DISPATCHER_COUNT = new AtomicInteger();

    private final InMemoryBroker broker;
    private final Duration blockedTimeout;
    private final boolean publisherConfirms;
    private final AtomicBoolean closed = new AtomicBoolean();
    private final java.util.List<InMemorySubscription> subscriptions = new java.util.concurrent.CopyOnWriteArrayList<>();

    InMemoryConnection(InMemoryBroker broker, Duration blockedTimeout, boolean publisherConfirms) {
        this.broker = broker;
        this.blockedTimeout = blockedTimeout;
        this.publisherConfirms = publisherConfirms;
    }

    @Override
    public boolean isBlocked() {
        return broker.blockedReason() != null;
    }

    @Override
    public java.util.Optional<String> blockedReason() {
        return java.util.Optional.ofNullable(broker.blockedReason());
    }

    @Override
    public void declareExchange(String name, String type, boolean durable) {
        requireOpen();
        broker.declareExchange(name, type, durable);
    }

    @Override
    public void declareQueue(String name, QueueType type, boolean durable, Map<String, Object> arguments) {
        requireOpen();
        broker.declareQueue(name, type, durable, arguments);
    }

    @Override
    public void bindQueue(String queue, String exchange, String routingKey) {
        requireOpen();
        broker.bindQueue(queue, exchange, routingKey);
    }

    @Override
    public void deleteQueue(String name) {
        requireOpen();
        broker.deleteQueue(name);
    }

    @Override
    public ConfirmResult send(OutboundMessage message) {
        requireOpen();
        broker.awaitUnblocked(blockedTimeout);
        long startedAt = System.nanoTime();
        Set<String> delivered = broker.route(message);
        Duration latency = Duration.ofNanos(System.nanoTime() - startedAt);

        // Without confirms a real broker never says a message went nowhere, so neither does
        // this one, unless the publish asked to be confirmed whatever the mode.
        if (!publisherConfirms && !message.alwaysConfirmed()) {
            return ConfirmResult.confirmed(latency);
        }

        // An in-memory broker always accepts the message. Whether anything was bound to
        // receive it is a separate question, and the one that catches real mistakes — unless
        // the publisher said it did not want to be told, in which case reporting it anyway
        // would make the fake stricter than the broker it stands in for.
        return delivered.isEmpty() && message.mandatory()
                ? ConfirmResult.unroutable(latency, "no queue is bound for routing key '" + message.routingKey() + "'")
                : ConfirmResult.confirmed(latency);
    }

    @Override
    public java.util.concurrent.CompletableFuture<org.acemq.amqp.transport.ConfirmResult> sendAsync(
            OutboundMessage message) {
        // Routing here is a map lookup, so there is no round trip to overlap and nothing to gain
        // from deferring it. Completing immediately keeps the semantics identical to the real
        // transport -- the future carries the same answer -- without pretending to a speed-up the
        // fake cannot deliver.
        try {
            return java.util.concurrent.CompletableFuture.completedFuture(send(message));
        } catch (RuntimeException e) {
            java.util.concurrent.CompletableFuture<org.acemq.amqp.transport.ConfirmResult> failed = new java.util.concurrent.CompletableFuture<>();
            failed.completeExceptionally(e);
            return failed;
        }
    }

    @Override
    public java.util.Optional<org.acemq.amqp.transport.PulledMessage> receive(String queueName, Duration timeout) {
        requireOpen();
        InMemoryBroker.Queue queue = broker.queue(queueName);
        OutboundMessage message;
        try {
            message = queue.poll(Math.max(0L, timeout.toMillis()));
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new TransportException("interrupted while reading from '" + queueName + "'", e);
        }
        if (message == null) {
            return java.util.Optional.empty();
        }

        InboundDelivery delivery = new InboundDelivery(
                queueName,
                message.exchange(),
                message.routingKey(),
                message.body(),
                message.headers(),
                message.messageId(),
                message.contentType(),
                false,
                message.replyTo().orElse(null));

        AtomicBoolean settled = new AtomicBoolean();
        Acknowledger acknowledger = new Acknowledger() {

            @Override
            public void accept() {
                // Accepting is what removes it: the poll already took it off the queue, so
                // there is nothing left to do but refuse a second settlement.
                settleOnce();
            }

            @Override
            public void reject(boolean requeue) {
                settleOnce();
                if (requeue) {
                    // Ahead of everything undelivered, so a drain that passes messages over and
                    // returns them leaves the queue in the order it found it.
                    queue.requeue(message);
                }
            }

            private void settleOnce() {
                if (!settled.compareAndSet(false, true)) {
                    throw new IllegalStateException("this message has already been settled");
                }
            }
        };
        return java.util.Optional.of(new org.acemq.amqp.transport.PulledMessage(delivery, acknowledger));
    }

    @Override
    public long messageCount(String queueName) {
        requireOpen();
        return broker.queue(queueName).depth();
    }

    @Override
    public Subscription subscribe(String queue, int prefetch, DeliveryListener listener) {
        requireOpen();
        if (prefetch < 1) {
            throw new IllegalArgumentException("prefetch must be at least 1, was " + prefetch);
        }
        InMemorySubscription subscription = new InMemorySubscription(broker.queue(queue), prefetch, listener,
                subscriptions);
        subscriptions.add(subscription);
        subscription.start();
        return subscription;
    }

    @Override
    public boolean queueExists(String name) {
        requireOpen();
        return broker.hasQueue(name);
    }

    @Override
    public QueueCheck checkQueue(String name, QueueType type, boolean durable, Map<String, Object> arguments) {
        requireOpen();
        return broker.checkQueue(name, type, durable, arguments);
    }

    @Override
    public boolean isOpen() {
        return !closed.get();
    }

    @Override
    public void close() {
        if (!closed.compareAndSet(false, true)) {
            return;
        }
        subscriptions.forEach(InMemorySubscription::close);
        subscriptions.clear();
    }

    private void requireOpen() {
        if (closed.get()) {
            throw new TransportException("the connection is closed");
        }
    }

    /**
     * Delivers messages from one queue to one listener.
     *
     * <p>A single dispatcher thread pulls from the queue, and a semaphore caps how many
     * deliveries may be unsettled at once. That is prefetch, modelled the same way a broker
     * models it, so a test can observe backpressure rather than only assuming it.
     */
    /** A semaphore whose permit count can be lowered; {@code reducePermits} is protected. */
    private static final class ResizableSemaphore extends Semaphore {

        private static final long serialVersionUID = 1L;

        ResizableSemaphore(int permits) {
            super(permits);
        }

        void reduce(int permits) {
            reducePermits(permits);
        }
    }

    private static final class InMemorySubscription implements Subscription {

        private final InMemoryBroker.Queue queue;
        private final ResizableSemaphore unsettled;
        private final java.util.concurrent.atomic.AtomicInteger prefetch;
        private final DeliveryListener listener;
        private final java.util.List<InMemorySubscription> registry;
        private final ExecutorService dispatcher;
        private final AtomicBoolean active = new AtomicBoolean(true);

        InMemorySubscription(
                InMemoryBroker.Queue queue,
                int prefetch,
                DeliveryListener listener,
                java.util.List<InMemorySubscription> registry) {
            this.queue = queue;
            this.unsettled = new ResizableSemaphore(prefetch);
            this.prefetch = new java.util.concurrent.atomic.AtomicInteger(prefetch);
            this.listener = listener;
            this.registry = registry;
            ThreadFactory factory = runnable -> {
                Thread thread = new Thread(runnable, "acemq-memory-dispatch-" + DISPATCHER_COUNT.incrementAndGet());
                thread.setDaemon(true);
                return thread;
            };
            this.dispatcher = Executors.newSingleThreadExecutor(factory);
        }

        @Override
        public void setPrefetch(int updated) {
            if (updated < 1) {
                throw new IllegalArgumentException("prefetch must be at least 1, was " + updated);
            }
            // The semaphore is the prefetch here, so raising it releases permits and lowering it
            // takes them back. Taking them back cannot reclaim what is already in flight, which
            // matches a real broker: those deliveries have been sent.
            int previous = prefetch.getAndSet(updated);
            int difference = updated - previous;
            if (difference > 0) {
                unsettled.release(difference);
            } else if (difference < 0) {
                unsettled.reduce(-difference);
            }
        }

        void start() {
            // execute rather than submit: submit hands back a Future that nobody
            // reads, so an exception escaping the pump loop would be captured in it
            // and never seen. The dispatcher would stop, the queue would stop being
            // consumed, and the test would hang rather than fail. With execute the
            // exception reaches the thread's uncaught handler and is printed.
            dispatcher.execute(this::pump);
        }

        private void pump() {
            while (active.get()) {
                try {
                    if (!unsettled.tryAcquire(50, TimeUnit.MILLISECONDS)) {
                        continue; // at the prefetch limit: wait for a settlement
                    }
                    OutboundMessage message = queue.poll(50);
                    if (message == null) {
                        unsettled.release();
                        continue;
                    }
                    if (!active.get()) {
                        // Cancelled while this poll was blocked. The message was taken but
                        // never delivered, so it goes back — without this, cancelling races
                        // with a waiting poll and lets exactly one more message through,
                        // which is precisely the message a drain was trying not to take.
                        queue.requeue(message);
                        unsettled.release();
                        return;
                    }
                    deliver(message);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    return;
                } catch (RuntimeException e) {
                    // A listener that throws must not kill the dispatcher, or the queue stops
                    // being consumed and the test hangs rather than failing.
                    unsettled.release();
                }
            }
        }

        private void deliver(OutboundMessage message) {
            InboundDelivery delivery = new InboundDelivery(
                    queue.name(),
                    message.exchange(),
                    message.routingKey(),
                    message.body(),
                    message.headers(),
                    message.messageId(),
                    message.contentType(),
                    false,
                    message.replyTo().orElse(null));

            AtomicBoolean settled = new AtomicBoolean();
            Acknowledger acknowledger = new Acknowledger() {
                @Override
                public void accept() {
                    if (settled.compareAndSet(false, true)) {
                        unsettled.release();
                    }
                }

                @Override
                public void reject(boolean requeue) {
                    if (settled.compareAndSet(false, true)) {
                        if (requeue) {
                            queue.requeue(message);
                        }
                        unsettled.release();
                    }
                }
            };

            listener.onDelivery(delivery, acknowledger);

            // A listener that returns without settling would leak a prefetch slot. Real
            // brokers hold the message until the connection drops; here it is surfaced
            // immediately, because a silent leak in a fake is a debugging nightmare.
            if (!settled.get()) {
                unsettled.release();
                throw new TransportException("the delivery listener returned without settling a delivery from queue '"
                        + queue.name() + "'. Every delivery must be accepted or rejected exactly once.");
            }
        }

        @Override
        public String queue() {
            return queue.name();
        }

        @Override
        public boolean isActive() {
            return active.get();
        }

        @Override
        public void cancel() {
            if (!active.compareAndSet(true, false)) {
                return;
            }
            // The pump loop checks this flag, so nothing new is taken. The dispatcher is asked
            // to stop but not waited for: a handler still running finishes on its own.
            dispatcher.shutdown();
            registry.remove(this);
        }

        @Override
        public void close() {
            if (!active.compareAndSet(true, false)) {
                // Already cancelled. Still wait for the dispatcher, because closing promises
                // that in-flight deliveries have settled.
                awaitDispatcher();
                registry.remove(this);
                return;
            }
            // shutdown, not shutdownNow. The subscription contract says in-flight deliveries
            // are let alone to finish settling, and shutdownNow interrupts them — which turns a
            // clean stop into a redelivery and makes draining impossible to implement on top.
            // The pump loop already stops on the inactive flag, so nothing new is taken.
            awaitDispatcher();
            registry.remove(this);
        }

        private void awaitDispatcher() {
            // shutdown, not shutdownNow. The subscription contract says in-flight deliveries
            // are let alone to finish settling, and shutdownNow interrupts them — which turns a
            // clean stop into a redelivery.
            dispatcher.shutdown();
            try {
                if (!dispatcher.awaitTermination(30, TimeUnit.SECONDS)) {
                    // Only now, and only because something is genuinely stuck.
                    dispatcher.shutdownNow();
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }
}
