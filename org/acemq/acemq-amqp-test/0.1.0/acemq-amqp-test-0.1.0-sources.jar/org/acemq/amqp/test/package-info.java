/*
 * Copyright 2026 AceMQ.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * Testing support for applications and for AceMQ itself.
 *
 * <p>The in-memory transport implements the same SPI as a real broker binding, so a test can
 * exercise the whole engine without Docker. Because it is the same seam, the conformance suite
 * can be run against both, which is how the fake is kept from quietly diverging.
 */

@org.jspecify.annotations.NullMarked
package org.acemq.amqp.test;
