/*
 * Copyright 2026 AceMQ.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.acemq.amqp.core;

import java.time.Duration;
import java.util.Collections;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

import org.acemq.amqp.api.Envelope;
import org.acemq.amqp.api.MetricNames;
import org.acemq.amqp.api.Telemetry;
import org.jspecify.annotations.Nullable;

import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.DistributionSummary;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Tags;
import io.micrometer.core.instrument.Timer;

/**
 * Records AceMQ activity into a Micrometer registry.
 *
 * <p>Only reached when Micrometer is on the classpath and a registry has been supplied, which
 * is why the core can depend on it optionally: an application without Micrometer never loads
 * this class and never pays for it.
 *
 * <p>Tag cardinality is chosen carefully. Queue, exchange and message type are bounded by the
 * topology, so they are safe. Message identifiers and routing keys containing identifiers are
 * not, which is why the message id appears on spans, where a high-cardinality value is useful,
 * and never on a metric, where it would multiply the time series until the backend fell over.
 */
final class MicrometerTelemetry implements Telemetry {

    private final MeterRegistry registry;
    private final String transport;
    private final AtomicInteger inFlight = new AtomicInteger();

    MicrometerTelemetry(MeterRegistry registry, String transport) {
        this.registry = registry;
        this.transport = transport;
    }

    @Override
    public Scope publishStarted(String exchange, String routingKey, Envelope envelope) {
        Tags tags = Tags.of(
                MetricNames.TAG_EXCHANGE, exchange == null ? "" : exchange,
                MetricNames.TAG_ROUTING_KEY, routingKey == null ? "" : routingKey,
                MetricNames.TAG_MESSAGE_TYPE, envelope.type(),
                MetricNames.TAG_TRANSPORT, transport);
        return new MeterScope(MetricNames.PUBLISH_DURATION, MetricNames.PUBLISH_TOTAL, tags, null);
    }

    @Override
    public Scope consumeStarted(String queue, Envelope envelope) {
        Tags tags = Tags.of(
                MetricNames.TAG_QUEUE, queue,
                MetricNames.TAG_MESSAGE_TYPE, envelope.type(),
                MetricNames.TAG_TRANSPORT, transport);

        DistributionSummary.builder(MetricNames.CONSUME_ATTEMPTS)
                .description("which delivery attempt a message was on when it was handled")
                .tags(tags)
                .register(registry)
                .record(envelope.attempt());

        inFlight.incrementAndGet();
        registry.gauge(MetricNames.CONSUME_IN_FLIGHT, tags, inFlight);
        return new MeterScope(MetricNames.CONSUME_DURATION, MetricNames.CONSUME_TOTAL, tags, inFlight);
    }

    @Override
    public void messageRetried(String queue, Envelope envelope, Duration delay) {
        Counter.builder(MetricNames.RETRIED_TOTAL)
                .description("messages sent to a retry queue for another attempt")
                .tags(Tags.of(
                        MetricNames.TAG_QUEUE, queue,
                        MetricNames.TAG_MESSAGE_TYPE, envelope.type(),
                        MetricNames.TAG_TRANSPORT, transport))
                .register(registry)
                .increment();
    }

    @Override
    public void messageDeadLettered(String queue, Envelope envelope, String reason) {
        // The reason is not a tag. It contains exception messages, which are unbounded, and a
        // metrics backend meets unbounded tags by falling over. It belongs on the span and in
        // the message header, both of which tolerate it.
        Counter.builder(MetricNames.DEAD_LETTERED_TOTAL)
                .description("messages sent to a dead-letter or parking queue")
                .tags(Tags.of(
                        MetricNames.TAG_QUEUE, queue,
                        MetricNames.TAG_MESSAGE_TYPE, envelope.type(),
                        MetricNames.TAG_TRANSPORT, transport,
                        MetricNames.TAG_OUTCOME, MetricNames.OUTCOME_DEAD_LETTERED))
                .register(registry)
                .increment();
    }

    @Override
    public void messageParked(String queue, Envelope envelope, String reason) {
        // The same counter as a dead-lettering, separated by the outcome tag rather than by a
        // metric of its own: both are a message set aside, and an operator asking "how much is
        // this queue giving up on" wants one number that can then be split.
        Counter.builder(MetricNames.DEAD_LETTERED_TOTAL)
                .description("messages sent to a dead-letter or parking queue")
                .tags(Tags.of(
                        MetricNames.TAG_QUEUE, queue,
                        MetricNames.TAG_MESSAGE_TYPE, envelope.type(),
                        MetricNames.TAG_TRANSPORT, transport,
                        MetricNames.TAG_OUTCOME, MetricNames.OUTCOME_PARKED))
                .register(registry)
                .increment();
    }

    @Override
    public void setAsideFailed(String queue, String target, String reason) {
        // The reason is not a tag, for the same cardinality reason as a dead-letter reason.
        Counter.builder(MetricNames.SET_ASIDE_FAILED)
                .description("messages that could not be moved to a dead-letter or parking queue")
                .tags(Tags.of(
                        MetricNames.TAG_QUEUE, queue,
                        MetricNames.TAG_TARGET, target,
                        MetricNames.TAG_TRANSPORT, transport))
                .register(registry)
                .increment();
    }

    @Override
    public void retryRungMissing(String queue, String rung, Duration delay) {
        // The rung is a tag and the delay is not. A policy names a fixed handful of rungs, so
        // the first is bounded and is the one an operator acts on — it is the queue to declare.
        // The delay is whatever arithmetic produced, and a tag whose values are durations has no
        // bound on it at all.
        Counter.builder(MetricNames.RUNG_MISSING)
                .description("retries that waited in the consumer because their rung queue is missing")
                .tags(Tags.of(
                        MetricNames.TAG_QUEUE, queue,
                        MetricNames.TAG_RUNG, rung,
                        MetricNames.TAG_TRANSPORT, transport))
                .register(registry)
                .increment();
    }

    @Override
    public Scope requestStarted(String destination, Envelope envelope) {
        Tags tags = Tags.of(
                MetricNames.TAG_ROUTING_KEY, destination == null ? "" : destination,
                MetricNames.TAG_MESSAGE_TYPE, envelope.type(),
                MetricNames.TAG_TRANSPORT, transport);
        return new MeterScope(MetricNames.REQUEST_DURATION, MetricNames.REQUEST_TOTAL, tags, null);
    }

    @Override
    public void outboxPublished(String exchange, String routingKey, Duration lag) {
        Tags tags = Tags.of(
                MetricNames.TAG_EXCHANGE, exchange == null ? "" : exchange,
                MetricNames.TAG_ROUTING_KEY, routingKey == null ? "" : routingKey,
                MetricNames.TAG_TRANSPORT, transport);

        // A timer rather than a counter, because the question is never "how many" but "how far
        // behind", and a percentile answers that where a total does not.
        Timer.builder(MetricNames.OUTBOX_LAG)
                .description("how long an outbox record waited between being committed and published")
                .tags(tags)
                .register(registry)
                .record(lag);
        Counter.builder(MetricNames.OUTBOX_TOTAL)
                .description("outbox records the relay has handled")
                .tags(tags.and(MetricNames.TAG_OUTCOME, MetricNames.OUTCOME_PUBLISHED))
                .register(registry)
                .increment();
    }

    @Override
    public void outboxFailed(String exchange, String routingKey, String reason) {
        // The reason is not a tag, for the same cardinality reason as a dead-letter reason.
        Counter.builder(MetricNames.OUTBOX_TOTAL)
                .description("outbox records the relay has handled")
                .tags(Tags.of(
                        MetricNames.TAG_EXCHANGE, exchange == null ? "" : exchange,
                        MetricNames.TAG_ROUTING_KEY, routingKey == null ? "" : routingKey,
                        MetricNames.TAG_TRANSPORT, transport,
                        MetricNames.TAG_OUTCOME, MetricNames.OUTCOME_FAILED))
                .register(registry)
                .increment();
    }

    @Override
    public void pipelineRunFinished(String pipeline, String step, String outcome, Duration age) {
        Tags tags = Tags.of(
                MetricNames.TAG_PIPELINE, pipeline,
                MetricNames.TAG_STEP, step,
                MetricNames.TAG_OUTCOME, outcome,
                MetricNames.TAG_TRANSPORT, transport);

        Timer.builder(MetricNames.PIPELINE_RUN_DURATION)
                .description("how long a message had existed when it left a pipeline")
                .tags(tags)
                .register(registry)
                .record(age);
        Counter.builder(MetricNames.PIPELINE_RUN_TOTAL)
                .description("pipeline runs that finished")
                .tags(tags)
                .register(registry)
                .increment();
    }

    @Override
    public Map<String, String> propagationHeaders() {
        // Metrics carry no context across the broker; tracing does that.
        return Collections.emptyMap();
    }

    /** Times one operation and counts how it ended. */
    private final class MeterScope implements Scope {

        private final String durationMetric;
        private final String countMetric;
        private final Tags tags;
        private final @Nullable AtomicInteger gauge;
        private final Timer.Sample sample;
        private @Nullable String outcome;
        private boolean closed;

        MeterScope(
                String durationMetric, String countMetric, Tags tags, @Nullable AtomicInteger gauge) {
            this.durationMetric = durationMetric;
            this.countMetric = countMetric;
            this.tags = tags;
            this.gauge = gauge;
            this.sample = Timer.start(registry);
        }

        @Override
        public void outcome(String outcome) {
            this.outcome = outcome;
        }

        @Override
        public void failed(Throwable failure) {
            if (this.outcome == null) {
                this.outcome = MetricNames.OUTCOME_FAILED;
            }
        }

        @Override
        public void close() {
            if (closed) {
                return;
            }
            closed = true;
            if (gauge != null) {
                gauge.decrementAndGet();
            }
            // An operation that closed without saying how it went almost certainly threw.
            String result = outcome == null ? MetricNames.OUTCOME_FAILED : outcome;
            Tags withOutcome = tags.and(MetricNames.TAG_OUTCOME, result);

            sample.stop(Timer.builder(durationMetric)
                    .description("how long the operation took")
                    .tags(withOutcome)
                    .publishPercentileHistogram()
                    .register(registry));
            Counter.builder(countMetric).tags(withOutcome).register(registry).increment();
        }
    }
}
