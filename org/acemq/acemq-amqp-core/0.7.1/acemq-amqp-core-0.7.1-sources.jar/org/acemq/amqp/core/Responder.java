/*
 * Copyright 2026 AceMQ.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.acemq.amqp.core;

import java.time.Duration;
import java.util.concurrent.atomic.AtomicLong;
import java.util.function.Function;

import org.acemq.amqp.api.AceHeaders;
import org.acemq.amqp.api.Envelope;
import org.acemq.amqp.api.Message;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * The other end of {@link Requester}: reads a request, computes an answer, sends it back.
 *
 * <pre>{@code
 * try (Responder responder = mq.respond("pricing", Quote.class, Price.class, quote -> price(quote))) {
 *     // serving until closed
 * }
 * }</pre>
 *
 * <p>The reply goes wherever the request asked, and carries the request's correlation id back
 * unchanged. Neither is the handler's problem. A request names its reply queue twice — the
 * {@code acemq-reply-to} header and AMQP's own {@code reply-to} property, always the same value —
 * and this reads the header first and the property second, so a caller that wrote only one of
 * them is still answered.
 */
public final class Responder implements AutoCloseable {

    private static final Logger log = LoggerFactory.getLogger(Responder.class);

    private final MessageConsumer consumer;

    // Initialised where they are declared, which puts them in place before the constructor body
    // runs and so before mq.consume(...) is called. That matters: a broker may hand the first
    // request over from inside the subscribe -- what a queue with a backlog looks like from in
    // here -- and the handler reads these fields on that very delivery. .NET had to lift its
    // counters out of the responder to get the same guarantee, because there they were reached
    // through a reference the subscribe had not returned yet.
    private final AtomicLong answered = new AtomicLong();
    private final AtomicLong unanswerable = new AtomicLong();

    <Q, A> Responder(
            AceMq mq, String queue, Class<Q> requestType, ConsumerOptions options, Function<Q, A> handler) {
        this.consumer = mq.consume(queue, requestType, options, message -> {
            // Header first, native property second, and that order is the contract in all five
            // libraries. A requester writes both, so either alone identifies an older or a
            // foreign caller: Go, Python and Ruby have only ever written the header, Java and
            // .NET only ever wrote the property. Reading both makes every pairing work, and
            // preferring the header means a message that crossed a hop which rebuilt it -- a
            // retry rung, a dead-letter, a shovel -- is still answerable, because the property
            // does not survive that and the header does.
            String replyTo = replyAddress(message);
            if (replyTo == null) {
                // A request nobody can answer. Failing here would retry it forever and
                // eventually dead-letter it; the honest thing is to handle it, count it, and
                // say so once -- the sender is the thing that is broken.
                unanswerable.incrementAndGet();
                log.warn(
                        "a message on {} asked for no reply, so none was sent. It was published"
                                + " without a reply-to, which usually means the sender used publish"
                                + " where it meant to use request.",
                        queue);
                return;
            }

            A answer = handler.apply(message.payload());

            // The empty exchange: reply-to names a queue directly. The correlation id is the
            // caller's, carried back unchanged -- it is the only thing tying the answer to the
            // question.
            Envelope reply = Envelope.of(answer == null ? "Reply" : answer.getClass().getSimpleName())
                    .correlationId(message.envelope().correlationId())
                    .build();

            // Counted before the reply goes out, and that order is the contract. The reply and
            // the counter are two things one caller can see, and publishing first leaves a
            // window in which a caller already holding its answer reads answered() as zero -- a
            // dashboard reporting an idle service that is demonstrably working. Incrementing
            // first puts the counter ahead of the reply in every interleaving there is, which is
            // the only ordering a reader can rely on. .NET fixed this first and deliberately did
            // not follow Java here; this is Java catching up, and all five libraries now promise
            // the same thing. A publish that throws hands its increment back on the way out, so
            // the failure incrementing early would otherwise introduce -- a send that never
            // happened counted as an answer -- does not exist either.
            answered.incrementAndGet();
            try {
                mq.<A>publisher("", replyTo).send(answer, reply);
            } catch (RuntimeException | Error failed) {
                answered.decrementAndGet();
                throw failed;
            }
        });
    }

    /**
     * How many requests were answered, counted before each reply left.
     *
     * <p>A caller holding a reply can rely on this having counted it: the increment happens
     * before the publish, so there is no interleaving in which the answer is visible and the
     * number is not. A publish that fails takes its increment back, so this counts replies that
     * were sent rather than replies that were attempted. Neither number needs a wait before it
     * can be trusted, and code that sleeps before reading one is working around a defect that is
     * fixed.
     *
     * @return how many requests were answered
     */
    public long answered() {
        return answered.get();
    }

    /**
     * How many arrived with no reply-to, counted before the delivery is acknowledged.
     *
     * <p>Anything above zero means a caller is publishing where it means to request.
     *
     * @return how many could not be answered
     */
    public long unanswerable() {
        return unanswerable.get();
    }

    /** @return whether this responder is still serving */
    public boolean isRunning() {
        return consumer.isRunning();
    }

    /**
     * Reads where the answer goes: the {@code acemq-reply-to} header, then AMQP's own
     * {@code reply-to} property.
     *
     * @param message the request
     * @return the reply queue, or {@code null} when the request named neither
     */
    private static @org.jspecify.annotations.Nullable String replyAddress(Message<?> message) {
        Object header = message.envelope().headers().get(AceHeaders.REPLY_TO);
        if (header != null) {
            String named = header.toString();
            if (!named.isEmpty()) {
                return named;
            }
        }
        return message.replyTo().orElse(null);
    }

    @Override
    public void close() {
        // Drained rather than cut off: a request being answered right now has a caller blocked
        // on the other side, and dropping it turns their call into a timeout.
        consumer.drain(Duration.ofSeconds(10));
        consumer.close();
    }
}
