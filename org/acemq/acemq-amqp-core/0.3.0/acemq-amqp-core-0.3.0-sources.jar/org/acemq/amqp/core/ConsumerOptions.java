/*
 * Copyright 2026 AceMQ.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.acemq.amqp.core;

import org.acemq.amqp.api.Codec;
import org.acemq.amqp.api.IdempotencyStore;
import org.acemq.amqp.api.RetryPolicy;
import org.jspecify.annotations.Nullable;

/** How a consumer should behave. */
public final class ConsumerOptions {

    private final int prefetch;
    private final boolean requeueOnFailure;
    private final @Nullable RetryPolicy retryPolicy;
    private final @Nullable IdempotencyStore idempotencyStore;
    private final @Nullable Codec codec;

    private ConsumerOptions(
            int prefetch,
            boolean requeueOnFailure,
            @Nullable RetryPolicy retryPolicy,
            @Nullable IdempotencyStore idempotencyStore,
            @Nullable Codec codec) {
        if (prefetch < 1) {
            throw new IllegalArgumentException("prefetch must be at least 1, was " + prefetch);
        }
        this.prefetch = prefetch;
        this.requeueOnFailure = requeueOnFailure;
        this.retryPolicy = retryPolicy;
        this.idempotencyStore = idempotencyStore;
        this.codec = codec;
    }

    /**
     * @return a prefetch of 50 with failures rejected rather than requeued
     * @implNote failures are not requeued by default. Requeueing a message that just failed
     *     sends it straight back to the same consumer, which spins at full speed and starves
     *     every other message. Until the retry ladder exists, rejecting is the honest
     *     behaviour: the message goes to a dead-letter queue if one is configured.
     */
    public static ConsumerOptions defaults() {
        return new ConsumerOptions(50, false, null, null, null);
    }

    /**
     * @param prefetch maximum unacknowledged deliveries at once
     * @return options with that prefetch
     */
    public static ConsumerOptions prefetch(int prefetch) {
        return new ConsumerOptions(prefetch, false, null, null, null);
    }

    /**
     * Requeues a message when its handler fails.
     *
     * <p>Only safe when the handler is expected to succeed on another consumer, such as when
     * shedding load. Using it for ordinary failures produces a hot loop.
     *
     * @return options that requeue on failure
     */
    public ConsumerOptions requeueOnFailure() {
        return new ConsumerOptions(prefetch, true, retryPolicy, idempotencyStore, codec);
    }

    /**
     * Retries failures on a schedule, never in a sleeping handler.
     *
     * <p>Turning this on makes the consumer declare a dead-letter queue, a parking lot, and one
     * retry rung per distinct delay the policy wants the <em>broker</em> to hold — see
     * {@link RetryPolicy#brokerWaitThreshold()}. A schedule that runs in a few seconds needs no
     * rungs at all, and gets none.
     *
     * <p>A failed message is republished either way, with its attempt counter advanced. Above
     * the threshold it goes into the rung and comes back when the time-to-live expires; below
     * it the engine holds the delivery for the wait and puts it back on the source queue. Once
     * the attempts or the age limit are used up it lands in the dead-letter queue with the
     * reason attached.
     *
     * @param retryPolicy the schedule to follow
     * @return options with retries enabled
     */
    public ConsumerOptions withRetry(RetryPolicy retryPolicy) {
        return new ConsumerOptions(prefetch, requeueOnFailure,
                java.util.Objects.requireNonNull(retryPolicy, "retryPolicy"), idempotencyStore, codec);
    }

    /**
     * Handles each message at most once, by remembering which have been handled.
     *
     * <p>Brokers deliver at least once, so a duplicate is a normal event rather than a fault:
     * a consumer that dies between doing the work and acknowledging it will see the message
     * again. With a store configured, the second delivery is acknowledged without running the
     * handler.
     *
     * <p>This makes the delivery idempotent, not the handler. Work the handler does outside
     * the store's knowledge — a row written, a payment taken — is only protected to the extent
     * that the store and that work fail together, which is why a store sharing the handler's
     * database is stronger than one in memory.
     *
     * @param store where handled identifiers are remembered
     * @return options with deduplication enabled
     */
    public ConsumerOptions idempotent(IdempotencyStore store) {
        return new ConsumerOptions(
                prefetch, requeueOnFailure, retryPolicy, java.util.Objects.requireNonNull(store, "store"), codec);
    }

    /**
     * Reads this queue with one named format instead of whatever arrives.
     *
     * <p>Almost never needed. A consumer normally says nothing about format, because the content
     * type on each message picks the codec, and that is what lets a producer change format
     * without a consumer change.
     *
     * <p>It is needed for Avro and Protobuf, and the reason is the same one that stops them
     * having an {@code asAvro()}: their bytes carry no description of themselves, so a reader
     * that has not been told the schema cannot construct one on seeing the message. Self
     * describing formats need nothing here; schema-bound formats must be named at both ends.
     *
     * @param codec the format to read with
     * @return a copy of these options reading that format
     */
    public ConsumerOptions as(Codec codec) {
        return new ConsumerOptions(
                prefetch, requeueOnFailure, retryPolicy, idempotencyStore,
                java.util.Objects.requireNonNull(codec, "codec"));
    }

    /** @return the format this consumer was told to read, if it was told one */
    public java.util.Optional<Codec> codec() {
        return java.util.Optional.ofNullable(codec);
    }

    /** @return the idempotency store, when one is configured */
    public java.util.Optional<IdempotencyStore> idempotencyStore() {
        return java.util.Optional.ofNullable(idempotencyStore);
    }

    /** @return the retry schedule, when one is configured */
    public java.util.Optional<RetryPolicy> retryPolicy() {
        return java.util.Optional.ofNullable(retryPolicy);
    }

    public int prefetch() {
        return prefetch;
    }

    public boolean isRequeueOnFailure() {
        return requeueOnFailure;
    }
}
