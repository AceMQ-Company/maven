/*
 * Copyright 2026 AceMQ.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.acemq.amqp.codec.avro;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;

import org.acemq.amqp.api.AceMqException;
import org.acemq.amqp.api.Codec;
import org.acemq.amqp.api.SchemaDefinition;
import org.acemq.amqp.api.SchemaRegistry;
import org.apache.avro.Schema;
import org.apache.avro.generic.GenericDatumReader;
import org.apache.avro.generic.GenericDatumWriter;
import org.apache.avro.io.BinaryDecoder;
import org.apache.avro.io.BinaryEncoder;
import org.apache.avro.io.DatumReader;
import org.apache.avro.io.DatumWriter;
import org.apache.avro.io.DecoderFactory;
import org.apache.avro.io.EncoderFactory;
import org.apache.avro.specific.SpecificDatumReader;
import org.apache.avro.specific.SpecificDatumWriter;
import org.apache.avro.specific.SpecificRecord;
import org.jspecify.annotations.Nullable;

/**
 * Reads and writes Avro.
 *
 * <p>There is no {@code asAvro()} and there cannot be one. Avro's bytes describe nothing about
 * themselves: a reader must already hold the schema the writer used, or the message is
 * unreadable. A method taking no arguments would have nothing to build a codec out of, so this is
 * reached through {@code publisher.as(AvroCodec.of(schema))} instead. That asymmetry with JSON is
 * not an oversight in the API; it is the difference between the formats, made visible.
 *
 * <p>Two ways to say where the schema comes from, and the choice matters more than it looks.
 *
 * <p>{@link #of(Schema)} and {@link #of(Class)} fix one schema for the codec's whole life. Small,
 * fast, and nothing extra to run — and the writer's schema is whatever the reader happens to have
 * compiled in. The moment a producer adds a field, every consumer still holding the old schema
 * reads the new bytes wrongly, and Avro will not always notice. Sound only where producer and
 * consumer are released together.
 *
 * <p>{@link #registered(SchemaRegistry)} writes the schema's identifier into the front of every
 * message, so a reader can look up exactly what the writer used and let Avro resolve it against
 * its own. This is what makes a field addition safe, and it is the mode to use unless there is a
 * reason not to. The framing is one zero byte, then four bytes of identifier, big-endian, then
 * the Avro body — the layout Confluent's clients use, so messages written here can be read by
 * them and the other way round.
 *
 * <p>The two framings are told apart by the content type, not by the bytes. A fixed-schema codec
 * handed {@code avro/binary} decodes the body as it stands; handed
 * {@code application/vnd.acemq.avro} it refuses, because reading the other framing would shift
 * every field and report nonsense as success. Only a message that arrived saying nothing useful
 * falls back to guessing from the first byte, and that guess is a last resort rather than a rule:
 * an Avro body begins with a zero byte whenever its first field encodes to zero — an empty string,
 * a {@code 0}, a {@code false}, the first branch of a union — so the byte alone cannot tell a
 * framed message from an ordinary one.
 */
public final class AvroCodec implements Codec {

    /** Content type for a codec whose schema is fixed at construction. */
    public static final String FIXED_CONTENT_TYPE = "avro/binary";

    /** Content type for a codec that writes a schema identifier into each message. */
    public static final String REGISTERED_CONTENT_TYPE = "application/vnd.acemq.avro";

    private static final byte MAGIC = 0;
    private static final int HEADER_BYTES = 5;

    /**
     * Schemas parsed back from the registry, kept so that a definition is turned into a Schema
     * once rather than on every message. Parsing Avro text is not cheap and the answer never
     * changes: an identifier stands for one schema forever.
     */
    private final Map<Integer, Schema> parsed = new ConcurrentHashMap<>();

    private final @Nullable Schema fixedSchema;
    private final @Nullable SchemaRegistry registry;
    private final boolean specific;

    private AvroCodec(@Nullable Schema fixedSchema, @Nullable SchemaRegistry registry, boolean specific) {
        this.fixedSchema = fixedSchema;
        this.registry = registry;
        this.specific = specific;
    }

    /**
     * @param schema the one schema this codec reads and writes; payloads are
     *     {@link org.apache.avro.generic.GenericRecord}
     * @return a codec fixed to that schema
     */
    public static AvroCodec of(Schema schema) {
        return new AvroCodec(Objects.requireNonNull(schema, "schema"), null, false);
    }

    /**
     * @param type a class generated by the Avro compiler, which carries its own schema
     * @return a codec fixed to that class's schema
     */
    public static AvroCodec of(Class<? extends SpecificRecord> type) {
        Objects.requireNonNull(type, "type");
        try {
            SpecificRecord prototype = type.getDeclaredConstructor().newInstance();
            return new AvroCodec(prototype.getSchema(), null, true);
        } catch (ReflectiveOperationException e) {
            throw new AceMqException(type.getName() + " does not look like a class the Avro compiler generated:"
                    + " it needs a no-argument constructor and a schema of its own", e);
        }
    }

    /**
     * @param registry where schema identifiers are resolved
     * @return a codec that writes an identifier into every message, so that a reader can resolve
     *     the writer's schema against its own
     */
    public static AvroCodec registered(SchemaRegistry registry) {
        return new AvroCodec(null, Objects.requireNonNull(registry, "registry"), false);
    }

    /**
     * As {@link #registered(SchemaRegistry)}, but reading every message against a schema of your
     * own rather than the writer's.
     *
     * <p>This is what schema evolution actually needs. With a writer's schema alone, a consumer
     * receives whatever the producer sent — a field it has never heard of arrives, and a field it
     * expects is simply absent if the producer has not started sending it yet. Given both, Avro
     * resolves them: a field the reader does not know is skipped, and one the writer omitted is
     * filled in from the reader's default. The consumer then sees the shape it was written
     * against, whichever version produced the message.
     *
     * <p>The alternative is a generated {@code SpecificRecord}, whose class carries the reader
     * schema. This exists for the generic path, where there is no class to read it from.
     *
     * @param registry where schema identifiers are resolved
     * @param readerSchema the schema this consumer was written against
     * @return a codec that resolves every message onto {@code readerSchema}
     */
    public static AvroCodec registered(SchemaRegistry registry, Schema readerSchema) {
        return new AvroCodec(
                Objects.requireNonNull(readerSchema, "readerSchema"),
                Objects.requireNonNull(registry, "registry"),
                false);
    }

    @Override
    public String contentType() {
        return registry != null ? REGISTERED_CONTENT_TYPE : FIXED_CONTENT_TYPE;
    }

    @Override
    public byte[] encode(Object payload) {
        Schema schema = schemaOf(payload);
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        try {
            if (registry != null) {
                int id = registry.idFor(definitionOf(schema));
                out.write(MAGIC);
                out.write((id >>> 24) & 0xFF);
                out.write((id >>> 16) & 0xFF);
                out.write((id >>> 8) & 0xFF);
                out.write(id & 0xFF);
            }
            BinaryEncoder encoder = EncoderFactory.get().binaryEncoder(out, null);
            writerFor(schema).write(payload, encoder);
            encoder.flush();
            return out.toByteArray();
        } catch (IOException | RuntimeException e) {
            throw new AceMqException("could not encode a " + payload.getClass().getName() + " as Avro against schema "
                    + schema.getFullName(), e);
        }
    }

    @Override
    public <T> T decode(byte[] body, Class<T> target) {
        // A caller who reached decode directly said nothing about what the bytes are, so the
        // guess below is all there is to go on.
        return decode(body, target, null);
    }

    @Override
    public <T> T decode(byte[] body, Class<T> target, @Nullable String contentType) {
        try {
            Schema writerSchema;
            int offset;
            if (registry != null) {
                if (body.length < HEADER_BYTES || body[0] != MAGIC) {
                    throw new AceMqException("this message has no schema identifier on the front of it. A codec"
                            + " built with registered() reads messages written by one, and these bytes were"
                            + " written by a codec with a fixed schema or by something else entirely.");
                }
                int id = (body[1] & 0xFF) << 24 | (body[2] & 0xFF) << 16 | (body[3] & 0xFF) << 8 | body[4] & 0xFF;
                writerSchema = parsed.computeIfAbsent(id, known -> {
                    SchemaDefinition definition = registry.schemaFor(known);
                    if (!"avro".equals(definition.format())) {
                        throw new AceMqException("schema id " + known + " is registered as " + definition.format()
                                + ", and this codec reads avro. The message was written by something else.");
                    }
                    return new Schema.Parser().parse(definition.definition());
                });
                offset = HEADER_BYTES;
            } else {
                // Framing this codec cannot read, caught before Avro turns it into nonsense.
                // Without this the five bytes of identifier are decoded as the beginning of the
                // first field: no exception, and a record whose every value is wrong. A caller
                // that reached decode directly never went through canDecode, so the check has
                // to exist here too.
                //
                // The content type is the signal, and it is asked first. A leading zero byte is
                // not evidence of framing on its own: an Avro body starts with one whenever its
                // first field encodes to zero -- an empty string, a 0, a false, the first branch
                // of a union -- all ordinary values. Guessing from the byte alone refuses those
                // real messages, so the guess is kept for the one case where there is nothing
                // else: a sender that said nothing at all.
                String type = contentType == null ? null : contentType.toLowerCase(Locale.ROOT);
                if (type != null && type.startsWith(REGISTERED_CONTENT_TYPE)) {
                    throw new AceMqException("these bytes carry a schema identifier and this codec"
                            + " has a fixed schema, so reading them would silently produce the wrong"
                            + " values. Build the codec with registered(registry) to read messages"
                            + " written by a registered one.");
                }
                if (!saysFixedSchema(type) && body.length >= HEADER_BYTES && body[0] == MAGIC) {
                    throw new AceMqException("these bytes look like they carry a schema identifier and"
                            + " nothing said what they are, so a codec with a fixed schema will not"
                            + " guess. Build the codec with registered(registry), or set the message's"
                            + " content type to " + FIXED_CONTENT_TYPE + " if the schema really is fixed.");
                }
                writerSchema = requireFixedSchema();
                offset = 0;
            }

            // Reader schema and writer schema are both given to Avro, which is the whole point:
            // it resolves the difference, so a field the writer added and the reader does not
            // know is skipped rather than shifting every field after it.
            Schema readerSchema = readerSchemaFor(target, writerSchema);
            DatumReader<Object> reader = specific
                    ? new SpecificDatumReader<>(writerSchema, readerSchema)
                    : new GenericDatumReader<>(writerSchema, readerSchema);
            BinaryDecoder decoder = DecoderFactory.get().binaryDecoder(body, offset, body.length - offset, null);
            Object decoded = reader.read(null, decoder);
            return target.cast(decoded);
        } catch (AceMqException e) {
            throw e;
        } catch (IOException | RuntimeException e) {
            throw new AceMqException("could not decode a message as " + target.getName() + ": " + e.getMessage(), e);
        }
    }

    @Override
    public boolean canDecode(@Nullable String contentType) {
        if (contentType == null) {
            // Avro bytes are not recognisable, so volunteering for a message whose sender said
            // nothing would mean decoding whatever arrived and reporting nonsense as success.
            return false;
        }
        String type = contentType.toLowerCase(Locale.ROOT);
        // The two framings are not interchangeable and the difference is invisible in the bytes:
        // a registered message begins with five bytes of framing that a fixed-schema codec would
        // read as the first field. That does not throw -- Avro decodes the shifted bytes into
        // whatever they happen to mean -- so a codec that accepted the other framing would hand
        // back a record full of silent nonsense. Each accepts only its own.
        if (type.startsWith(REGISTERED_CONTENT_TYPE)) {
            return registry != null;
        }
        if (type.startsWith(FIXED_CONTENT_TYPE) || type.startsWith("avro/")) {
            return registry == null;
        }
        return type.contains("avro") && !type.contains("acemq.avro");
    }

    /**
     * Whether a content type says, in so many words, that a body carries no framing in front of
     * the Avro. Anything else -- absent, {@code application/octet-stream}, something unrelated --
     * says nothing useful and leaves the guess to do the work.
     */
    private static boolean saysFixedSchema(@Nullable String lowercased) {
        if (lowercased == null) {
            return false;
        }
        return lowercased.startsWith(FIXED_CONTENT_TYPE)
                || lowercased.startsWith("avro/")
                || lowercased.startsWith("application/avro")
                || lowercased.contains("+avro");
    }

    /**
     * @param schema an Avro schema
     * @return the same schema as a registry sees it, so it can be registered before anything is
     *     published
     */
    public static SchemaDefinition definitionOf(Schema schema) {
        Objects.requireNonNull(schema, "schema");
        return new SchemaDefinition("avro", schema.getFullName(), schema.toString());
    }

    private Schema schemaOf(Object payload) {
        if (payload instanceof SpecificRecord) {
            return ((SpecificRecord) payload).getSchema();
        }
        if (payload instanceof org.apache.avro.generic.GenericContainer) {
            return ((org.apache.avro.generic.GenericContainer) payload).getSchema();
        }
        if (fixedSchema != null) {
            return fixedSchema;
        }
        throw new AceMqException("a " + payload.getClass().getName() + " carries no Avro schema, and this codec was"
                + " built without one. Use AvroCodec.of(schema), or publish a GenericRecord or a generated class.");
    }

    private Schema requireFixedSchema() {
        if (fixedSchema == null) {
            throw new AceMqException("this codec has no schema to read with");
        }
        return fixedSchema;
    }

    private Schema readerSchemaFor(Class<?> target, Schema writerSchema) {
        if (SpecificRecord.class.isAssignableFrom(target)) {
            try {
                return ((SpecificRecord) target.getDeclaredConstructor().newInstance()).getSchema();
            } catch (ReflectiveOperationException e) {
                throw new AceMqException("could not read the schema out of " + target.getName(), e);
            }
        }
        // A GenericRecord asks for nothing in particular, so the writer's schema is also the
        // reader's and no resolution happens.
        return fixedSchema != null ? fixedSchema : writerSchema;
    }

    private DatumWriter<Object> writerFor(Schema schema) {
        return specific ? new SpecificDatumWriter<>(schema) : new GenericDatumWriter<>(schema);
    }

    @Override
    public String toString() {
        return "AvroCodec{" + (registry != null ? "registry" : "schema=" + requireFixedSchema().getFullName()) + "}";
    }
}
