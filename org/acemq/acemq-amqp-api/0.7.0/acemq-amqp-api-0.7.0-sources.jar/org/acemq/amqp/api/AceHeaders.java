/*
 * Copyright 2026 AceMQ.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.acemq.amqp.api;

/**
 * The message header names that make up the AceMQ cross-language contract.
 *
 * <p>These names are the interoperability surface of the whole project. A Go publisher and
 * an Elixir consumer agree because they agree on these strings, and a service that does not
 * use AceMQ at all can still read them. They are frozen at specification version 1:
 * renaming one is a breaking change for every language port simultaneously.
 *
 * <p>Two groups of names here deliberately do not carry the {@code x-acemq-} prefix. Trace
 * context does not, because {@code traceparent} and {@code tracestate} are W3C names that other
 * tools already know how to read. The {@link #SHARED_PREFIX} names do not, because they are
 * written by a pattern rather than by the engine and have to reach the handler: a header in the
 * reserved namespace is stripped on consume, which for these would mean writing them and finding
 * them gone.
 */
public final class AceHeaders {

    /**
     * The engine's namespace.
     *
     * <p><strong>Reserved.</strong> A header carrying this prefix is treated as the engine's,
     * materialised as a field on the {@link Envelope} if it is one this version knows about,
     * and <em>dropped from the application's headers either way</em>. Putting your own header
     * here means writing it on publish and finding it gone on consume, with nothing reporting
     * the loss.
     *
     * <p>Use a namespace of your own — {@code x-yourcompany-} — for anything the application or
     * a pattern needs to survive the round trip.
     */
    public static final String PREFIX = "x-acemq-";

    /**
     * The namespace AceMQ defines but does not reserve.
     *
     * <p>A header here is one AceMQ writes and reads, but it is an ordinary application header
     * on the wire: {@link #isAceHeader} does not match it, {@code Envelope.Builder.header}
     * accepts it, and it survives to the handler like any other. That is the whole point. A
     * responder has to read the reply address out of the message it was handed, and a handler
     * has to be able to see that the message it is looking at came back off a dead-letter queue.
     * Put either in the reserved namespace and the engine eats it on the way in.
     *
     * <p>Go, Python and Ruby use exactly these strings for exactly these headers. Java used to
     * put the replay three in the reserved namespace, and was alone in doing so.
     */
    public static final String SHARED_PREFIX = "acemq-";

    /** Unique message identifier, and the default idempotency key. */
    public static final String ID = PREFIX + "id";

    /** Logical message type, for example {@code order.placed}. */
    public static final String TYPE = PREFIX + "type";

    /** Schema version of the payload, as an integer. */
    public static final String VERSION = PREFIX + "version";

    /** Business correlation identifier, propagated unchanged across hops. */
    public static final String CORRELATION = PREFIX + "correlation";

    /** Identifier of the message that caused this one to be published. */
    public static final String CAUSATION = PREFIX + "causation";

    /** Delivery attempt counter, starting at 1 and incremented by the retry engine. */
    public static final String ATTEMPT = PREFIX + "attempt";

    /** Epoch milliseconds of the first publish, used for age-based give-up. */
    public static final String FIRST_SEEN = PREFIX + "first-seen";

    /** Identifier of the publishing process, conventionally {@code service@host}. */
    public static final String ORIGIN = PREFIX + "origin";

    /**
     * Where the payload is, when the application stores it outside the message.
     *
     * <p>Materialised as {@link Envelope#claim()}. Set by the application, never by the engine,
     * and never interpreted by it — it is for an operator reading a dead-letter queue.
     *
     * <p><strong>Not written by the claim-check pattern</strong>, which frames its reference in
     * the body and sets no header, because a header can be stripped by a shovel or a federation
     * link. All five libraries make that choice deliberately.
     */
    public static final String CLAIM = PREFIX + "claim";

    /** Why a message was dead-lettered. Present only on messages in a dead-letter queue. */
    public static final String ERROR = PREFIX + "error";

    /**
     * Queue a request's reply should be sent to.
     *
     * <p>Written alongside AMQP's own {@code reply-to} property rather than instead of it, and
     * read in preference to it. The property is the older of the two and the one a non-AceMQ
     * service understands; the header is what Go, Python and Ruby have always written, and the
     * only one of the pair that survives a broker hop that rebuilds the message. Writing both
     * and reading either is what lets a requester in one language be answered by a responder in
     * another, in both directions and whichever of them is older.
     */
    public static final String REPLY_TO = SHARED_PREFIX + "reply-to";

    /**
     * A self-describing itinerary: the stops a message still has to make, as JSON.
     *
     * <p>The other half of {@link RoutingSlip#ROUTE}, which names steps and leaves a declared
     * pipeline to say where each one lives. This header carries the exchange and routing key of
     * every stop with it, so a consumer that has never heard of the pipeline can still send the
     * message on. Go, Python and Ruby write this one; a declared pipeline is the better model
     * when there is a declaration, and this is what there is when there is not.
     */
    public static final String ROUTING_SLIP = SHARED_PREFIX + "routing-slip";

    /** Queue a message was replayed from, set by the replay API for auditing. */
    public static final String REPLAYED_FROM = SHARED_PREFIX + "replayed-from";

    /** When the message was last replayed. */
    public static final String REPLAYED_AT = SHARED_PREFIX + "replayed-at";

    /**
     * How many times the message has been replayed.
     *
     * <p>Worth carrying separately from the attempt count, which a replay resets. A message on
     * its fifth trip through a dead-letter queue is saying something that a fresh-looking
     * attempt counter would hide.
     */
    public static final String REPLAY_COUNT = SHARED_PREFIX + "replay-count";

    /** W3C trace context. Not prefixed, so non-AceMQ tooling recognises it. */
    public static final String TRACEPARENT = "traceparent";

    /** W3C trace state. Not prefixed, for the same reason as {@link #TRACEPARENT}. */
    public static final String TRACESTATE = "tracestate";

    private AceHeaders() {
        throw new AssertionError("AceHeaders is a constant holder and must not be instantiated");
    }

    /**
     * Reports whether a header name belongs to AceMQ.
     *
     * <p>Useful when copying headers between messages: AceMQ-owned headers are re-derived by
     * the engine rather than propagated verbatim.
     *
     * @param headerName header name to test, may be {@code null}
     * @return {@code true} if the name carries the {@link #PREFIX}
     */
    public static boolean isAceHeader(String headerName) {
        return headerName != null && headerName.startsWith(PREFIX);
    }
}
