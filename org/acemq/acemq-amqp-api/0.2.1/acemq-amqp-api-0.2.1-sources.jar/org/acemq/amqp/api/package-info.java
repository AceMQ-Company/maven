/*
 * Copyright 2026 AceMQ.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * The public AceMQ AMQP API.
 *
 * <p>This package carries no third-party dependencies by design. It is the module
 * from which every other language port is transliterated, so anything added here
 * becomes a cross-language commitment.
 */

@org.jspecify.annotations.NullMarked
package org.acemq.amqp.api;
