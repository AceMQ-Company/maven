/*
 * Copyright 2026 AceMQ.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.acemq.amqp.transport;

import java.util.Map;

/**
 * An open connection to one broker.
 *
 * <p>Implementations must be safe to use from several threads. Whatever multiplexing the
 * protocol requires — AMQP 0-9-1 channels, AMQP 1.0 sessions and links — is the transport's
 * business and is never exposed, because a caller holding a channel is a caller who breaks
 * when the transport changes.
 */
public interface TransportConnection extends AutoCloseable {

    /**
     * Declares an exchange, or verifies that an equivalent one exists.
     *
     * @param name exchange name
     * @param type routing behaviour: {@code direct}, {@code topic}, {@code fanout} or
     *     {@code headers}
     * @param durable whether it survives a broker restart
     * @throws TransportException if an incompatible exchange already exists
     */
    void declareExchange(String name, String type, boolean durable);

    /**
     * Declares a queue, or verifies that an equivalent one exists.
     *
     * @param name queue name
     * @param type queue implementation to request
     * @param durable whether it survives a broker restart
     * @param arguments broker-specific queue arguments, may be empty
     * @throws TransportException if an incompatible queue already exists. AMQP forbids
     *     changing most arguments in place, so this is reported rather than worked around.
     */
    void declareQueue(String name, QueueType type, boolean durable, Map<String, Object> arguments);

    /**
     * Binds a queue to an exchange.
     *
     * @param queue queue name
     * @param exchange exchange name
     * @param routingKey routing key or pattern
     */
    void bindQueue(String queue, String exchange, String routingKey);

    /**
     * Publishes one message and waits for the broker to confirm it.
     *
     * <p>Blocking is deliberate. An asynchronous publish that nobody waits on is the most
     * common way to lose messages, so the safe shape is the default one; batching and
     * pipelining belong to the core, which knows when they are appropriate.
     *
     * @param message the message to publish
     * @return what the broker said, including whether anything was bound to receive it
     * @throws TransportException if the connection failed or the confirm timed out
     */
    ConfirmResult send(OutboundMessage message);

    /**
     * Starts consuming a queue.
     *
     * @param queue queue to consume
     * @param prefetch maximum unsettled deliveries allowed at once; must be at least 1, and is
     *     the only backpressure that exists, so it is required rather than defaulted
     * @param listener receives each delivery
     * @return a handle that stops delivery when closed
     * @throws TransportException if the queue cannot be consumed
     */
    Subscription subscribe(String queue, int prefetch, DeliveryListener listener);

    /**
     * Starts consuming a queue with broker-specific consumer arguments.
     *
     * <p>Exists for streams. A stream consumer says where in the log to start with an
     * {@code x-stream-offset} argument, and there is nowhere else to put it: it belongs to the
     * subscription rather than to the queue, because two consumers of one stream read from
     * different positions.
     *
     * <p>The default refuses rather than ignores. Dropping the arguments would leave a consumer
     * that asked to replay a stream from the beginning quietly reading only new messages —
     * working, plausible, and missing everything it was written to process.
     *
     * @param queue queue to consume
     * @param prefetch maximum unsettled deliveries allowed at once
     * @param consumerArguments broker-specific arguments for this subscription
     * @param listener receives each delivery
     * @return a handle that stops delivery when closed
     * @throws TransportException if the queue cannot be consumed, or if this transport cannot
     *     honour the arguments given
     */
    default Subscription subscribe(
            String queue, int prefetch, Map<String, Object> consumerArguments, DeliveryListener listener) {
        if (consumerArguments == null || consumerArguments.isEmpty()) {
            return subscribe(queue, prefetch, listener);
        }
        throw new TransportException("this transport does not support consumer arguments, and was asked for "
                + consumerArguments.keySet() + " on queue '" + queue + "'. Consuming without them would read"
                + " from the wrong place rather than fail, so it is refused.");
    }

    /**
     * Publishes one message without waiting for the broker to confirm it.
     *
     * <p>The throughput answer to {@link #send}. A synchronous publish costs a full round trip per
     * message, so a loop over ten thousand messages spends nearly all of its time waiting; this
     * lets the next message go out while the last one is still being confirmed. Confirms come back
     * out of order and in ranges, which is why the correlation is the transport's job rather than
     * the caller's.
     *
     * <p>The safety properties are unchanged, and that is the point: the returned future carries
     * the same {@link ConfirmResult} the synchronous call returns, including whether anything was
     * bound to receive the message. What changes is when the caller learns it. <strong>A future
     * nobody waits on is a message nobody knows the fate of</strong> — which is the failure mode
     * this whole library exists to avoid, so the result must be checked, eventually, by somebody.
     *
     * <p>Implementations must bound the number of unconfirmed publishes and block once that limit
     * is reached. An unbounded async publisher is a memory leak that looks like throughput.
     *
     * <p>The default implementation publishes synchronously and hands back a completed future. It
     * is correct and offers no speed-up whatsoever, which is the honest behaviour for a transport
     * that cannot pipeline.
     *
     * @param message the message to publish
     * @return a future completed with the broker's answer
     * @throws TransportException if the message could not be written at all
     */
    default java.util.concurrent.CompletableFuture<ConfirmResult> sendAsync(OutboundMessage message) {
        return java.util.concurrent.CompletableFuture.completedFuture(send(message));
    }

    /**
     * Takes one message off a queue, or reports that there is none.
     *
     * <p>A pull, where {@link #subscribe} is a push. It exists for the jobs that have to stop
     * when a queue runs out — draining a dead-letter queue is the one this was written for. A
     * subscription cannot do that: it is told when a message arrives and never told that no more
     * are coming, so a tool built on one has to guess with an idle timeout and either stops early
     * or hangs on an empty queue.
     *
     * <p>Not for ordinary consuming. Pulling one message per round trip is far slower than a
     * subscription with prefetch, and a loop calling this is a consumer that has thrown away its
     * own backpressure.
     *
     * <p>The delivery is unsettled: the caller must accept or reject it through the
     * {@link Acknowledger}, exactly as a subscription must.
     *
     * @param queue queue to take from
     * @param timeout how long to wait for a message to appear
     * @return the message and its acknowledger, or empty when the queue had nothing within the
     *     timeout
     * @throws TransportException if the queue cannot be read
     */
    default java.util.Optional<PulledMessage> receive(String queue, java.time.Duration timeout) {
        throw new TransportException("this transport cannot pull single messages, which is what draining queue '"
                + queue + "' needs. Consuming it with a subscription instead would have no way to tell when the"
                + " queue was empty, so it is refused rather than approximated.");
    }

    /**
     * Counts the messages waiting in a queue.
     *
     * <p>For reporting what a drain would move before it moves anything. It is a snapshot and
     * nothing more: a live queue has a different depth by the time the number is read, so it
     * belongs in a report to a person, never in a loop condition.
     *
     * @param queue queue to measure
     * @return how many messages are waiting
     * @throws TransportException if the queue cannot be measured or does not exist
     */
    default long messageCount(String queue) {
        throw new TransportException("this transport cannot report the depth of queue '" + queue + "'");
    }

    /**
     * Whether the broker is currently refusing publishes.
     *
     * <p>Worth exposing rather than only throwing, because this is the state a health check
     * should report and an autoscaler should read. A blocked broker is not a broken one, and a
     * service that reports itself unhealthy the moment a memory alarm fires will be restarted
     * by its orchestrator, which helps nobody.
     *
     * @return whether publishing is currently blocked at the broker
     */
    default boolean isBlocked() {
        return false;
    }

    /** @return the broker's stated reason for blocking, when it is blocked */
    default java.util.Optional<String> blockedReason() {
        return java.util.Optional.empty();
    }

    /**
     * Removes a queue and everything in it.
     *
     * @param name queue to delete
     * @implNote provided for test fixtures and topology migration. Ordinary application code
     *     should not be deleting queues.
     */
    void deleteQueue(String name);

    /**
     * Reports whether a queue exists, without creating or altering it.
     *
     * <p>Separate from declaring because a planner has to be able to look before it
     * touches anything. Declaring a queue that already exists with different arguments
     * does not merely fail: on AMQP 0-9-1 it kills the channel, which is why a topology
     * applied blindly at start-up fails in production rather than in review.
     *
     * @param name queue name
     * @return {@code true} if the queue is already present
     */
    boolean queueExists(String name);

    /**
     * Asks whether a queue that already exists would accept this declaration.
     *
     * <p>{@link #queueExists(String)} answers "is something there", which is the smaller half
     * of the question. The half that costs an outage is "is what is there the same as what this
     * release expects" — a queue whose {@code x-message-ttl} was changed by hand, or whose
     * dead-letter exchange was pointed somewhere else, or that somebody created as classic when
     * the topology says quorum. AMQP forbids changing any of those in place, so the declare
     * fails at start-up, in production, taking the channel with it.
     *
     * <p>The default answers {@link QueueCheck#unsupported()}. A transport that cannot inspect
     * a queue must not claim it matches: silence read as agreement is how drift gets missed.
     *
     * @param name queue name
     * @param type queue implementation the caller wants
     * @param durable whether the caller wants it to survive a restart
     * @param arguments the arguments the caller would declare
     * @return what the broker says, including {@link QueueCheck.Result#UNSUPPORTED} when it
     *     cannot be asked
     * @implSpec must not create the queue, and must not disturb traffic on other channels. The
     *     usual implementation asks passively first and, only for a queue that is already
     *     there, attempts an equivalence declare on a channel of its own.
     */
    default QueueCheck checkQueue(String name, QueueType type, boolean durable, Map<String, Object> arguments) {
        return QueueCheck.unsupported();
    }

    /** @return whether the connection is usable */
    boolean isOpen();

    /** Closes the connection, letting in-flight deliveries settle first. */
    @Override
    void close();
}
